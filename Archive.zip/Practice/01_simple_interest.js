function simpleInterest(p, r, t) {
  return (p * r * t) / 100;
}

function isApproximate(a, b) {
  const tolerence1 = a - b;
  const tolerence2 = b - a;
  const tolerence = a > b ? tolerence1 : tolerence2;
  return 0.05 > tolerence;
}

function testSimpleIterest(p, r, t, si) {
  const sI = simpleInterest(p, r, t);
  const resultInImage = isApproximate(si, sI) ? "✅" : "❌";
  console.log(
    resultInImage,
    "expected result",
    si,
    "output result",
    simpleInterest(p, r, t),
  );
}

testSimpleIterest(1000, 10, 3, 300);
testSimpleIterest(500, 5, 7, 175);
testSimpleIterest(1, 1, 1, 0.01);

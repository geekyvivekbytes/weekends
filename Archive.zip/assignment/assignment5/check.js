
function areInObjectType(array1, array2) {
  return typeof (array1) === 'object' && typeof (array2) === 'object';
}

function areDeepEqual(array1, array2) {

  if (array1.length !== array2.length) {
    return false;
  }
  
  for (let index = 0; index < array1.length; index++) {
    if (typeof (areInObjectType(array1, array2))) {
      if (!areDeepEqual(array1[index], array2[index])) {
        return false;
      }
    }
  }
  return true;
}


function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('equal array', areDeepEqual([1, 2, 3, 4], [1, 2, 3, 4]), true);
  test('equal but empty array', areDeepEqual([], []), true);
  test('nested with one array', areDeepEqual([1, [2, 3]], [1, [2, 3]]), true);
  test('array indside nested array', areDeepEqual([[2, [3]]], [[2, [3]]]), true);
  test('array with different nesting', areDeepEqual([[2, 3]], [[2, [3]]]), false);
}
runAllTests();
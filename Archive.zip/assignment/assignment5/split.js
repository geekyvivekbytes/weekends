// Given a string and a single-character delimiter, returns an array of strings
// obtained by splitting the input string at each occurrence of the delimiter.
// The delimiter must be a single character.
// Examples:
// split("a,b,c", ",") => ["a", "b", "c"]
// split("one:two:three", ":") => ["one", "two", "three"]
// split("hello", ",") => ["hello"]

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function split(sentence, delimiter) {
  const splitedSentence = [];
  let currentString = '';
  for (let index = 0; index < sentence.length; index++) {

    if (sentence[index] === delimiter) {
      splitedSentence.push(currentString);
      currentString = '';
    } else {
      currentString += sentence[index];
    }
  }
  splitedSentence.push(currentString);

  return splitedSentence;
}

function test(description, actual, expected) {
  if (areEqual(actual, expected)) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('one word seperation', split("a,b,c", ","), ["a", "b", "c"]);
  test('word seperation', split("one:two", ':'), ["one", 'two']);
  test('without delimiter', split("hello", ","), ["hello"]);
  test('start with delimiter', split(",hello", ","), ['', "hello"]);
  test('end with delimiter', split("hello,", ","), ["hello", '']);
}
runAllTests();
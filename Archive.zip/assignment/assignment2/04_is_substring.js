/*
  Implement the below function that tells if a string is substring of another string

  Usage:
    isSubstring('hello world', 'worl') => true
    isSubstring('repeating iiiiiiii', 'iii') => true
    isSubstring('not found', 'for') => false

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function isSubstr(string, subString, stringIndex) {
  for (let index = 0; index < subString.length; index++) {
    if (string[stringIndex] !== subString[index]) {
      return false;
    }
    stringIndex++;
  }
  return true;
}
function isSubstring(string, subString) {
  // Implementation here.
  let stringFound = false;
  for (let index = 0; index < string.length; index++) {
    if (string[index] === subString[0]) {
      stringFound = stringFound || isSubstr(string, subString, index);
    }
  }
  return stringFound;
}

function messageComposer(string, substring, expectedResult, indexLoction) {
  const verifyIndex = expectedResult === indexLoction;
  const emoji = verifyIndex ? '✅' : '❌';
  let message = emoji + '[' + string + ' , ' + substring + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + indexLoction + '|';
  return message;
}
function checkIsSubstring(string, subString, expectedResult) {
  const result = isSubstring(string, subString);
  const message = messageComposer(string, subString, expectedResult, result);
  console.log(message);
}
function all() {
  checkIsSubstring('lord of thunders', 'f th', true);
  checkIsSubstring('the lion king', 'lion', true);
  checkIsSubstring('the end is the beginning', '', false);
  checkIsSubstring('hello world', '', false);
  checkIsSubstring('the liiion', 'ion', true);
  checkIsSubstring('hello world', 'worl', true);
  checkIsSubstring('repeating iiiiiiii', 'iii', true);
  checkIsSubstring('not found', 'for', false);
}
all();
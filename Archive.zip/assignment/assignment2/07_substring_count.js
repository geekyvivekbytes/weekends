/*
  Write a function that counts the occurrence of a substring in a string

  Examples:
    occurrences('hello world', 'l') => 3
    occurrences('hello world', 'll') => 1
    occurrences('hello world', 'world') => 1
    occurrences('hello world', 'zebra') => 0

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function isSubstring(string, subString, stringIndex) {
  for (let index = 0; index < subString.length; index++) {
    if (string[stringIndex] !== subString[index]) {
      return 0;
    }
    stringIndex++;
  }
  return 1;
}
function occurrences(string, substring) {
  // Implementation here.
  let noOfSubstring = 0;
  for (let index = 0; index < string.length; index++) {
    if (string[index] === substring[0]) {
      noOfSubstring += isSubstring(string, substring, index);
    }
  }
  return noOfSubstring;
}
function checkOccurrences(string, subString, expected) {
  const noOfOccurrences = occurrences(string, subString);
  const isOccurrencesEql = noOfOccurrences === expected;
  const emoji = isOccurrencesEql ? "✅" : "❌";
  console.log(emoji, 'expected:', expected, 'actual:', noOfOccurrences);
}
function all() {
  checkOccurrences('finding index', 'in', 3);
  checkOccurrences('welcome to the world of coding', 'o', 5);
  checkOccurrences('hello', 'a', 0);
  checkOccurrences('hello world', '', 0);
  checkOccurrences('hahahaha haha', 'haha', 4);
  checkOccurrences('hahahaha ha', 'haha', 3);
}
all();
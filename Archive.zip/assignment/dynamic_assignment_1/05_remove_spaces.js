/*
  Implement the below function to replace every run of adjacent SPACE(" ")
  characters with a single SPACE in the given sentence.

  Rules:
  - Consider only the plain SPACE character (" "). Any contiguous sequence
    of one or more SPACE characters should become a single SPACE.
  - Leading and trailing runs of spaces are also collapsed to a single space.
  - Do NOT modify other whitespace characters: TAB("\t") and NEW LINE("\n")
    must remain exactly as they are.
  - Runs of spaces that are separated by other characters (including \t or \n)
    are treated separately and each such run is collapsed independently.

  Examples:
  removeAdjacentDuplicateSpaces("statement      with    two spaces")
    -> "statement with two spaces"
    (multiple spaces between words collapsed to single spaces)

  removeAdjacentDuplicateSpaces("   hello   world   ")
    -> " hello world "
    (leading/trailing runs collapsed to single leading/trailing space)
*/

function removeAdjacentDuplicateSpaces(sentence) {
  // Implementation here.
  let newSentence = '';

  for (let index = 0; index < sentence.length; index++) {
    if (!(sentence[index -1] === ' ' && sentence[index] === " ")) {
      newSentence = newSentence + sentence[index]
    }
  }
  return newSentence;
}

function messageComposer(sentence, expectedResult, removedSpaces) {
  const verifyString = expectedResult === removedSpaces;
  const emoji = verifyString ? '✅' : '❌';
  let message = emoji + '[' + sentence + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + removedSpaces + '|';
  return message;
}
function checkRemoveSpace(sentence, expectedResult) {
  const removedSpaces = removeAdjacentDuplicateSpaces(sentence);
  const message = messageComposer(sentence, expectedResult, removedSpaces);
  console.log(message);
}
function all() {
  checkRemoveSpace('   rajesh', ' rajesh');
  checkRemoveSpace('not    found', 'not found');
  checkRemoveSpace('hello  world', 'hello world');
  checkRemoveSpace('', '');
}
all();
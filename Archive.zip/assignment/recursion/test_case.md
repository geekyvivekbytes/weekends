| Description | Input | Output |
| --- | --- | --- |
| Simple increment of a normal day | 15-03-2021 | 16-03-2021 |
| Given date, Month, Year are 0 | 00-00-0000| "Invalid Date" |
| Checking for the first day of calendar | 01-01-0001| 02-01-0001 |
| Date is 0 | 00-11-2025| "Invalid Date" |
| Month section Contains 0 | 23-00-2342 | "Invalid Date" |
| Only year is 0 | 12-05-0000 | "Invalid Date" |
| Date is exceed for Months having 31 days like January | 32-01-2024 | "Invalid Date" |
| Date is exceed for the Months having 30 days like April | 31-04-2024 | "Invalid Date" |
| Month exceed than 12 | 01-13-2024 | "Invalid Date" |
| In Leap Year end of February Month change | 29-02-2024 | 01-03-2024 |
| Non Leap Year February month | 29-02-2026 | "Invalid Date" |
| Year seems like Leap Year | 29-02-1900 | "Invalid Date" |
| Change in year | 31-12-2024 | 01-01-2025 |
| Month change from Month having 31 days |31-01-2024 | 01-02-2024 |
| Month change from Month having 30 days |30-04-2024 | 01-05-2024 |
| August case as it has 31 days(two month have 31 days simultaneously) | 31-08-2024 | 01-09-2024 |


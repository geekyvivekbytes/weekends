function remainder(dividend, divisor) {
  if (dividend < divisor ) {
    return dividend;
  }
  return remainder(dividend - divisor, divisor);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('only dividend is 0', remainder(0, 5), 0);
  test('dividend is greater than divisor', remainder(45, 9), 0);
  test('divisor is greater than dividend', remainder(3, 4), 3);
}

runAllTests();


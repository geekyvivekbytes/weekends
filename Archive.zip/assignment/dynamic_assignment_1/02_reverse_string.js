/*
  Implement the below function to reverse the given sentence.
  Examples:
  reverseString("hello") returns "ollhe"
*/

function reverseString(sentence) {
  // Implementation here.
  let reversedString = '';
  const reverseIndex = sentence.length - 1
  for (let index = reverseIndex; index >= 0; index--) {
    reversedString = reversedString + sentence[index];
  }
  return reversedString;
}
function messageComposer(string, expectedResult, reversedString) {
  const verifyString = expectedResult === reversedString;
  const emoji = verifyString ? '✅' : '❌';
  let message = emoji + '[' + string + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + reversedString + '|';
  return message;
}
function checkreverseString(sentence, expectedResult) {
  const reversedString = reverseString(sentence);
  const message = messageComposer(sentence, expectedResult, reversedString);
  console.log(message);
}
function all() {
  checkreverseString('rajesh', 'hsejar');
  checkreverseString("mohit", 'tihom');
  checkreverseString('not found', 'dnuof ton');
  checkreverseString('hello world', 'dlrow olleh');
}
all();
function primeFactor(a) {
  let givenNumber = a;
  let divisior = 2;
  let factor = '';
  while (givenNumber > 1) {
    if (givenNumber % divisior === 0) {
      factor = factor + divisior + ' ';
      givenNumber = givenNumber / divisior;

    } else {
      divisior++;
    }
  }
  return factor;
}

function checkFactor(a, b) {
  const factors = primeFactor(a);
  const isFactorsTrue = factors === b;
  const resultInImage = isFactorsTrue ? "✅" : "❌";
  console.log(resultInImage, "output result is", factors, "and expected result was", b);
}

checkFactor(8, '2 2 2 ');
checkFactor (94, '2 47 ');
checkFactor (97, "97 ");

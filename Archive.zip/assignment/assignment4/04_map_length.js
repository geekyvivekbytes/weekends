// Given an array containing words, return a new array containing length of
// the words.
// mapLengths(["apple", "cat", "Four"]) => [5, 3, 4]
// do not modify input parameters

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function mapLengths(words) {
  const arrayWithLength = [];
  for (let index = 0; index < words.length; index++) {
    const lengthOfWord = words[index].length;
    arrayWithLength.push(lengthOfWord);
  }
  return arrayWithLength;
}

function test(description, actual, expected) {
  if (areEqual(actual, expected)) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('3 string element', mapLengths(['earth', 'sun', 'moon']), [5, 3, 4]);
  test('singleton array', mapLengths(['a']), [1]);
  test('empty array', mapLengths([]), []);
}
runAllTests();
/*
  Write a function that tells if a string ends with a specific substring

  Examples:
    endsWith('hello world', 'ld') => true
    endsWith('hello world', 'wor') => false
    endsWith('hello world', 'hello') => false

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function isSubstring(string, substring, stringIndex) {
  for (let index = 0; index < substring.length; index++) {
    if (string[stringIndex] !== substring[index]) {
      return false;
    }
    stringIndex++;
  }
  return true;
}

function endsWith(string, substring) {
  // Implementation here.
  let stringIndex = string.length - substring.length;
  return isSubstring(string, substring, stringIndex);
}

function Composer(string, substring, expectedResult, endsWithResult) {
  const areTheyEqual = expectedResult === endsWithResult;
  const emoji = areTheyEqual ? '✅' : '❌';
  let message = emoji + '[' + string + ' , ' + substring + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + endsWithResult + '|';
  return message;
}


function checkEndsWith(string, substring, expectedResult) {
  const endsWithResult = endsWith(string, substring);
  const message = Composer(string, substring, expectedResult, endsWithResult);
  console.log(message);
}

function all() {
  checkEndsWith('hello', 'lo', true);
  checkEndsWith('rakesh', 'esh', true);
  checkEndsWith('happy', 'cy', false);
  checkEndsWith('hello', ' ', false);
  checkEndsWith('hello', '', true);
  checkEndsWith('hello world', 'ld', true);
  checkEndsWith('hello world', 'wor', false);
  checkEndsWith('hello world', 'hello', false);
}

all();
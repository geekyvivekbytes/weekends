// Return all the elements of array1 which are not present in array2.
// difference([1, 2, 3], [2, 3, 4]) => [1]

function isArray(x) {
  return typeof x === 'object';
}

function areArraysEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (!areDeepEqual(array1[index], array2[index])) {
      return false;
    }
  }
  return true;
}

function areDeepEqual(array1, array2) {
  if (typeof array1 !== typeof array2) {
    return false;
  }

  if (isArray(array1) && isArray(array2)) {
    return areArraysEqual(array1, array2);
  }

  return array1 === array2;
}

function includes(array, target) {
  for (let index = 0; index < array.length; index++) {
    if (areDeepEqual(array[index], target)) {
      return true;
    }
  }
  return false;
}

function difference(array1, array2) {
  const elementNotInArray2 = [];
  for (let index = 0; index < array1.length; index++) {
    if (!includes(array2, array1[index])) {
      elementNotInArray2.push(array1[index]);
    }
  }
  return elementNotInArray2;
}

function test(description, actual, expected) {
  if (areDeepEqual(actual, expected)) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('all element present', difference([3, 5], [3, 5, 6]), []);
  test('no element is in 2nd one', difference([555, 65], [34, 43, 54]), [555, 65]);
}
runAllTests();
function dateToYear(date) {
  return parseInt(date.slice(-4));
}
function dateToDay(date) {
  return parseInt(date.slice(0, 3));
}
function dateToMonth(date) {
  return parseInt(date.slice(3, 5));
}

function integerToString(integer) {
  return integer + '';
}

function padInteger(integer, upto) {
  const string = integerToString(integer)
  return string.padStart(upto, '0');
}

function dateFormat(day, month, year) {
  return `${padInteger(day, 2)}-${padInteger(month, 2)}-${padInteger(year, 4)}`;
}

function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0 || year % 400 === 0 && year !== 0);
}

function isKnuckleMonth(month) {
  return ((month - 1) % 7) % 2 === 0;
}

function maximumDays(month, year) {
  if (month === 2) {
    return isLeapYear(year) ? 29 : 28;
  }
  return isKnuckleMonth(month) ? 31 : 30;
}

function changeDay(day, month, year) {
  let dayDate = day;
  dayDate = day + 1;
  return dayDate > maximumDays(month, year) ? 1 : dayDate;
}

function changeMonth(day, month) {
  if (day === 1 && month === 12) {
    return 1;
  }
  return day === 1 ? month + 1 : month;
}

function changeYear(day, month, year) {
  return month === 1 && day === 1 ? year + 1 : year;
}

function isDateValid(day, month, year) {
  if (day === 0 || month === 0) {
    return true;
  }
  if (day > maximumDays(month, year) || month > 12) {
    return true;
  }
  if (day === 31 && month === 12 && year === 9999) {
    return true;
  }
  return false;
}

function nextDate(date) {
  let day = dateToDay(date);
  let month = dateToMonth(date);
  let year = dateToYear(date);

  if (isDateValid(day, month, year)) {
    return 'Invalid Date';
  }

  day = changeDay(day, month, year);
  month = changeMonth(day, month);
  year = changeYear(day, month, year);

  return dateFormat(day, month, year);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('Given date, Month are 0', nextDate('00-00-0000'), "Invalid Date");
  test('Given, only year is zero', nextDate('01-01-0000'), "02-01-0000");
  test('Date is 0 ', nextDate('00-11-2025'), "Invalid Date");
  test('Month section Contains 0', nextDate('23-00-2342'), "Invalid Date");
  test('Only year is 0', nextDate('31-12-0000'), "01-01-0001");
  test('Month exceed than 12', nextDate('01-13-2024'), "Invalid Date");
  test('Year seems like Leap Year', nextDate('29-02-1900'), "Invalid Date");
  test('Change in year', nextDate('31-12-2024'), '01-01-2025');
  test("last day of calendar", nextDate("31-12-9999"), "Invalid Date");

}
runAllTests();
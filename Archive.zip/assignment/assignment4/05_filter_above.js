// Given an array of numbers and a threshold value, return a new array
// that contains all the numbers above the threshold.
// filterAbove([6, 2, 3, 1, 4, 7], 3) => [6, 4, 7]
// filterAbove([1, 2, 3], 4) => []
// do not modify input parameters

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function filterAbove(array, threshold) {
  const valueAboveThreshold = [];
  for (let index = 0; index < array.length; index++) {
    if (array[index] > threshold) {
      valueAboveThreshold.push(array[index]);
    }
  }
  return valueAboveThreshold;
}

function test(description, actual, expected) {
  if (areEqual(actual, expected)) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('singleton array', filterAbove([1], 1), []);
  test('4 length array', filterAbove([4, 3, 2, 1], 0), [4, 3, 2, 1]);
  test('empty array', filterAbove([], 0), []);
}
runAllTests();
const divisor = 3;
const divident = 569;
let quotient = 0;
let remainder = 0;

let auxdivisor = 0; 
while (auxdivisor < divident){
     if (auxdivisor + divisor <= divident){
          auxdivisor = auxdivisor + divisor;
          quotient = quotient + 1;
     }else{
          auxdivisor = auxdivisor + 1;
          remainder = remainder + 1;
     }
}
console.log('result quotient',quotient,'remainder',remainder);
/*
  Write a function that takes an integer as input and returns a string.

  If the integer is divisible by 3, return "fizz".
  If the integer is divisible by 5, return "buzz".
  If the integer is divisible by both 3 and 5, return "fizzbuzz".
  Otherwise, return the integer as a string.

  Examples:
    fizzBuzz(3) => "fizz"
    fizzBuzz(5) => "buzz"
    fizzBuzz(15)=> "fizzbuzz"
    fizzBuzz(7) => "7"
  
  **There won't be any negative numbers**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function fizzBuzz(number) {
  // Implementation here.
  const isDivisibleBy3 = number % 3 === 0;
  const isDivisibleBy5 = number % 5 === 0;
  if (isDivisibleBy3 === isDivisibleBy5) {
    return isDivisibleBy3 && isDivisibleBy5 ? 'fizzbuzz' : number + '';
  }
  if (isDivisibleBy3) {
    return 'fizz';
  }
  return 'buzz';
}
function messageComposer(number, expectedResult, actualResult) {
  const areResultSame = expectedResult === actualResult;
  const emoji = areResultSame ? '✅' : '❌';
  let message = emoji + '[' + number + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + actualResult + '|';
  return message;
}
function checkFizzBuzz(number, expectedResult) {
  const actualResult = fizzBuzz(number);
  const message = messageComposer(number, expectedResult, actualResult);
  console.log(message);
}
function all() {
  checkFizzBuzz(54, 'fizz');
  checkFizzBuzz(85, 'buzz');
  checkFizzBuzz(45, 'fizzbuzz');
  checkFizzBuzz(77, '77');
}
all();
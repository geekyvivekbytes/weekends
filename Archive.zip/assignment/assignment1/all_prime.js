// Do not rename startOfRange or endOfRange, use them as input for your program.
// While testing we will change their values.

const startOfRange = 0;
const endOfRange = 1;

// Print all prime numbers between startOfRange and endOfRange(both inclusive).
// For example, if startOfRange = 5 and endOfRange = 13, then the output should be
// 5
// 7
// 11
// 13
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
for (let term = startOfRange; term <= endOfRange; term++) {
  let isComposite = false;
  for (let divisor = 2; divisor < term; divisor++) {
    let isDivisible = term % divisor === 0;
    isComposite = isComposite || isDivisible;
  }
  let isPrime = !isComposite && term > 1;
  if (isPrime) {
    console.log(term);
  }
}

// Do not rename a, use it as input for your program.
// While testing we will change their values.
// n will be a natural number including 0.

const a = 11;

// Print the binary representation of a
// If a = 12, then the output should be
// 0
// 0
// 1
// 1

// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
let decimalNumber = a;
if (decimalNumber === 0) {
  console.log(decimalNumber);
}
while (decimalNumber > 0) {
  let binaryDigit = decimalNumber % 2;
  decimalNumber = (decimalNumber - binaryDigit) / 2;
  console.log(binaryDigit);
}
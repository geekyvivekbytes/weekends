function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function isOdd(number) {
  return number % 2 === 1;
}

function selectOdds(numbers) {
  const selectedOdds = [];
  for (let index = 0; index < numbers.length; index++) {
    if (isOdd(numbers[index])) {
      selectedOdds.push(numbers[index]);
    }
  }
  return selectedOdds;
}

function test(description, actual, expected) {
  if (areEqual(actual, expected)) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('singleton array', selectOdds([1]), [1]);
  test('4 length array', selectOdds([4, 3, 2, 1]), [3, 1]);
  test('empty array', selectOdds([]), []);
  test('array full of odd numbers', selectOdds([11, 31, 33]), [11, 31, 33]);
}
runAllTests();
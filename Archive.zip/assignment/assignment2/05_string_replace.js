/*
  Implement the below function 
  that replaces a character `match` with another character `replacement`
  in a given text and returns a new string.

  Examples:
    replace('hello world', 'l', 'n') => 'henno world'
    replace('no spaces in here', ' ', '_') => 'no_spaces_in_here'
    replace('', 'd', 'e') => ''

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function replace(text, match, replacement) {
  // Implementation here.
  let finalText = '';
  for (let index = 0; index < text.length; index++) {
    let character = text[index];
    character = text[index] === match ? replacement : character;
    finalText = finalText + character;
  }
  return finalText;
}
function checkReplace(text, match, replacement, expected) {
  const replaceResult = replace(text, match, replacement);
  const isReplacementEqual = replaceResult === expected;
  const resultInImage = isReplacementEqual ? "✅" : "❌";
  console.log(resultInImage, 'expected:', expected, 'actual:', replaceResult);
}
function all() {
  checkReplace('hello world', 'l', 'n', 'henno wornd');
  checkReplace('rohan', 'r', 'm', 'mohan');
  checkReplace('no spaces in here', ' ', '_', 'no_spaces_in_here');
  checkReplace('', 'd', 'e', '');
}
all();
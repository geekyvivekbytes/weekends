function checkIndex(string, char, index) {
  if (index === string.length) {
    return -1;
  }
  if (string[index] === char) {
    return index;
  }
  return checkIndex(string, char, index + 1);
}

function findIndex(string, char) {
  const index = 0;
  return checkIndex(string, char, index);
}
function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('helleh case', findIndex('helleh', 'l'), 2);
  test('hello case', findIndex('hello', 'h'), 0);
  test('hello case', findIndex('hello', 'a'), -1);
  test('hello case', findIndex('hello', ''), -1);
  test('empty string', findIndex('', ''), -1);
  test('one word', findIndex('_', '_'), 0);
}

runAllTests();
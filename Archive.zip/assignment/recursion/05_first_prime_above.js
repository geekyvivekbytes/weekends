function checkPrime(number, divisor) {
  if (number % divisor === 0) {
    divisor = 2;
    return checkPrime(number + 1, divisor);
  }  
  if ((number - 1) === divisor) {
    return number;
  }
  return checkPrime(number, divisor + 1);
}

function firstPrimeAbove(number) {
  if (number < 2) {
    return 2;
  }
  const divisor = 2;
  return checkPrime(number + 1, divisor);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('prime above 2', firstPrimeAbove(2), 3);
  test('prime above 1', firstPrimeAbove(1), 2);
  test('prime above 3', firstPrimeAbove(3), 5);
  test('prime above 0', firstPrimeAbove(0), 2);
  test('prime above 41', firstPrimeAbove(41), 43);
}

runAllTests();
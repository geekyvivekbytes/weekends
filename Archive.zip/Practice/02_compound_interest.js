function compoundInterest(p, r, t) {
  let auxiliaryPrinciple = p;

  for (let timePeriod = 1; timePeriod <= t; timePeriod = timePeriod + 1) {
    let simpleInterest = (auxiliaryPrinciple * r) / 100;
    auxiliaryPrinciple = auxiliaryPrinciple + simpleInterest;
  }
  return auxiliaryPrinciple - p;
}

function isApproximate(a, b) {
  const tolerence1 = a - b;
  const tolerence2 = b - a;
  const tolerence = a > b ? tolerence1 : tolerence2;
  return 0.05 > tolerence;
}

function testCaseOfCI(p, r, t, ci) {
  const cI = compoundInterest(p, r, t);
  const resultInImage = isApproximate(ci, cI) ? "✅" : "❌";
  console.log(
    resultInImage,
    "output result is",
    cI,
    "and expected result was",
    ci,
  );
}

testCaseOfCI(1000, 10, 1, 100);
testCaseOfCI(1000, 10, 3, 331);
testCaseOfCI(100, 50, 2, 125);

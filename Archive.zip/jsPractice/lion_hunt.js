const lion = "L";
const zeb = "Z";
let ani = "";
let poslion = 0;
let poszeb = 0;
let count =1;
const input = " Z  L L";
let distance1;
let distance = 0;

while(count < input.length){
    ani = input[count];
    if(ani === lion){
        poslion = count;
    }
    if(ani === zeb){
        poszeb = count;
    }
    distance1 = poszeb - poslion;
    if (distance1 < 0){
        distance1 = distance1 * (-1)
    }
    if(distance1 < distance){
        distance = distance1;
    }
    console.log(distance);
    
    count++;
}
// let distance = poszeb - poslion -1;
console.log(distance -1);
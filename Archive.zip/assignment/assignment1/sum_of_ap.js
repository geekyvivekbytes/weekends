// Do not rename a, d or n, use them as input for your program.
// While testing we will change its values.

const a = 1;
const d = 1;
const n = 10;

// Print the sum of first n terms of an AP where a is the first term and d is the common difference.
// Printing more than one output or printing anything other than simple interest might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
let sumOfAp = 0;
let nthTerm = a;
for (let term = 1; term <= n; term++) {
  sumOfAp = sumOfAp + nthTerm;
  nthTerm = nthTerm + d;
}
console.log(sumOfAp);

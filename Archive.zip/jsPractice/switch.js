const roll_no = 34;
switch (roll_no) {
    case 32:
        console.log('name of the student is vivek.'); 
        break;
    case 33:
        console.log('name of the student is rajesh.');
        break;
    case 34:
        console.log('name of the student is rahul.');
        break;
    default:
        console.log('roll_no not found');     
}

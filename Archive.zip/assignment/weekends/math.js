const totalRandomNo = 6;
let count = 0;
while (count < totalRandomNo) {
  let randomNo = Math.random();
  randomNo = randomNo * 10;
  randomNo = Math.floor(randomNo);
  console.log(randomNo);
  count++;
}

function messageComposer(discription, dividend, divisor, expectedResult, actualResult) {
  const verifyResult = expectedResult === actualResult;
  const emoji = verifyResult ? '✅' : '❌';
  if (verifyResult) {
    const message = `${emoji} ${discription}`;
    return message;
  }
  const message = `${emoji} ${discription} 
  Inputs  : [${dividend} , ${divisor}] 
  Actual  : ${actualResult}
  Expected: ${expectedResult}
  ---------`
  return message;
}

function checkquotient(discription, dividend, divisor, expectedResult) {
  const actualResult = quotient(dividend, divisor);
  const message = messageComposer(discription, dividend, divisor, expectedResult, actualResult);
  console.log(message);
}

function all() {
  checkquotient('divisor and dividend are 0', 0, 0, 'infinity');
  checkquotient('only dividend is 0', 0, 5, 0);
  checkquotient('only divisor is 0', 5, 0, 'infinity');
  checkquotient('both divisor and dividend are positive', 45, 9, 4);
  checkquotient('divisor is greater than dividend', 3, 4, 0);
}
all();
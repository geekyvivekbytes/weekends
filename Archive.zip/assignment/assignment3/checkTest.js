function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0 || year % 400 === 0 && year !== 0);
}

function is(month) {
  return month > 7 ? (month + 1) % 2 : month % 2;
  //return ((month - 1) % 7) % 2; 
}
function maximumDays(month, year) {
  if (month === 2) {
    return isLeapYear(year) ? 29 : 28;
  }
  return is(month) === 1 ? 31 : 30;
}

function formMessage(description, month, year, expected, actual) {
  const emoji = expected === actual ? '✅' : '❌';
  if (expected === actual) {
    return `[${emoji}] ${description}`;
  }
  return `[${emoji}] ${description} 
  Inputs  : [${month, year}] 
  Actual  : [${actual}]
  Expected: [${expected}]
  ---------`;
}

function test(description, month, year, expected) {
  const actual = maximumDays(month, year);
  const message = formMessage(description, month, year, expected, actual);
  console.log(message);
}

function runAllTest() {
  test('checking on month having 31 days ', 1, 2000, 31);
  test('checking on month having 29/29 days ', 2, 2000, 29);
  test('checking on month having 29/29 days ', 2, 0, 28);
  test('checking on month having 29/29 days ', 2, 2001, 28);
  test('checking on month having 31 days ', 3, 2000, 31);
  test('checking on month having 30 days ', 4, 2000, 30);
  test('checking on month having 31 days ', 5, 2000, 31);
  test('checking on month having 30 days ', 6, 2000, 30);
  test('checking on month having 31 days ', 7, 2000, 31);
  test('checking on month having 31 days ', 8, 2000, 31);
  test('checking on month having 30 days ', 9, 2000, 30);
  test('checking on month having 31 days ', 10, 2000, 31);
  test('checking on month having 30 days ', 11, 2000, 30);
  test('checking on month having 31 days ', 12, 2000, 31);

}
runAllTest();

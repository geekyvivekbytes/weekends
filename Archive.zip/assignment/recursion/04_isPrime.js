function checkPrime(primeCandidate, divisor) {
  if (primeCandidate % divisor === 0) {
    return false;
  }
  if ((primeCandidate - 1) === divisor) {
    return true;
  }
  return checkPrime(primeCandidate, divisor + 1);
}

function isPrime(primeCandidate) {
  if (primeCandidate < 2) {
    return false;
  }
  if (primeCandidate === 2) {
    return true;
  }
  let divisor = 2;
  return checkPrime(primeCandidate, divisor);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('2 should be prime', isPrime(2), true);
  test('primeCandidate is less than 2', isPrime(1), false);
  test('primeCandidate is divisible by 2', isPrime(4), false);
  test('41 should be prime', isPrime(41), true);
}

runAllTests();
// Given array1 and array2, returns true if both arrays are deeply equal, else false.
// Deep equality means both arrays contain the same elements in the same order,
// including any nested arrays, which must also be deeply equal.
// Examples:
// areDeepEqual([1, 2, 3], [1, 2, 3]) => true
// areDeepEqual([1, [2, 3]], [1, [2, 3]]) => true
// areDeepEqual([1, [2, 3]], [1, [3, 2]]) => false
// areDeepEqual([1, 2], [1, 2, 3]) => false
// areDeepEqual([1, [2, [3]]], [1, [2, [3]]]) => true
// areDeepEqual([1, [2, [3]]], [1, [2, 3]]) => false
// do not modify input parameters


function areInObjectType(array1, array2) {
  return typeof (array1) === 'object' && typeof (array2) === 'object';
}

function areDeepEqual(array1, array2) {
  
  if (!areInObjectType(array1, array2)) {
    return false;
  }

  if (array1.length !== array2.length) {
    return false;
  }
  
  for (let index = 0; index < array1.length; index++) {
    if (typeof (array1[index]) === 'object') {
      return areDeepEqual(array1[index], array2[index]);
    }
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}


function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('equal array', areDeepEqual([1, 2, 3, 4], [1, 2, 3, 4]), true);
  test('equal but empty array', areDeepEqual([], []), true);
  test('nested with one array', areDeepEqual([1, [2, 3]], [1, [2, 3]]), true);
  test('array indside nested array', areDeepEqual([[2, [3]]], [[2, [3]]]), true);
  test('array with different nesting', areDeepEqual([[2, 3]], [[2, [3]]]), false);
}
runAllTests();
const condition = 'Z   LL Z ';
let result = 0;

for (let index = 0 ; index < condition.length ; index++){
    if (condition[index]=== 'L' || condition[index] === 'Z'){
        for (let index2 = index ; index2 < condition.length ; index2++){
            if (condition[index2]!==condition[index] && condition[index2]!== ' ')
                if (result === 0){
                    result = (index2 - index);
                }else{
                    result = result > (index2 - index) ? (index2 - index) : result ;

            }
        }
    }
}
result = result - 1;
console.log(result);

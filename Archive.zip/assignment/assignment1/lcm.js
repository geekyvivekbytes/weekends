// Do not rename a or b, use them as input for your program.
// While testing we will change their values.
// a and b will be always 0 or greater.
const a = 8;
const b = 7;

// Print the lcm of a and b
// Printing more than one output or printing anything other than lcm might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let largestNumber = (a > b) ? a : b;
let lcm;
let findingLCM = true;
while (findingLCM) {
  if (largestNumber % a === 0 && largestNumber % b === 0) {
    lcm = largestNumber;
    findingLCM = false;
  }
  largestNumber++;
}
console.log(lcm);

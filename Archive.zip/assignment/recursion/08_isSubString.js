function checkEqual(string, substring, strIndex, subStrIndex) {
  if (string[strIndex] !== substring[subStrIndex]) {
    return false;
  }
  if (subStrIndex === substring.length - 1) {
    return true;
  }
  return checkEqual(string, substring, strIndex + 1, subStrIndex + 1);
}

function checkSubstring(string, substring, startIndex) {
  const subStrIndex = 0;
  if (checkEqual(string, substring, startIndex, subStrIndex)) {
    return true;
  }
  if (startIndex === string.length) {
    return false;
  }
  return checkSubstring(string, substring, startIndex + 1);
}

function isSubString(string, otherString) {
  if (string === '' || otherString === '') {
    return false;
  }
  const startIndex = 0;
  return checkSubstring(string, otherString, startIndex);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('helleh case', isSubString('helleh', 'leh'), true);
  test('hello case', isSubString('hello', 'lo'), true);
  test('hello case', isSubString('hello', 'olle'), false);
  test('empty string', isSubString('', ' '), false);
  test('empty string', isSubString(' ', ''), false);
  test('empty string', isSubString('', ''), false);
  test('one word', isSubString('_', '_'), true);
  test('sentence', isSubString('jump from \n empty space', 'm \n e'), true);
}

runAllTests();
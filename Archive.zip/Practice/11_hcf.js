function hcf(a, b) {
  let hcf;
  for (let divisor = 1; divisor <= a; divisor++) {
    if (a % divisor === 0 && b % divisor === 0) {
      hcf = divisor;
    }
  }
  return hcf;
}

function checkHCF(a, b, c) {
  const foundedHcf = hcf(a, b);
  const isHcf = foundedHcf === c;
  const resultInImage = isHcf ? "✅" : "❌";
  console.log(resultInImage, "output result is", foundedHcf, "and expected result was", c);
}

checkHCF(1, 1, 1);
checkHCF(12, 14, 2);
checkHCF(51, 17, 17);
//1
const temperature = 45;
const tempcondition = temperature > 30 ? 'hot' : 'cool';
console.log(tempcondition);

//2
const isMember = false;
const discount = isMember ? 10 : 10;
console.log(discount);

// discount = 10;
//3
const day = 'Monday';
const weekends = day === 'Saturday' || day === 'Sunday';
console.log(weekends);

//4
const cartItems = '';
const stats = cartItems.length === 0 ? 'empty' : 'ready';
console.log(stats);
//5
const marks = 87;
const grade = marks >= 90 ? 'A' : 'B';
console.log(grade, marks);
//6
const userType = 'admin';
const canDelete = userType === 'admin';
const baseAccess = canDelete ? 'all' : 'limited';
console.log(userType, canDelete, baseAccess);
//7
const isPremiumUser = true;
const basePrice = 655;
const discountPercentage = isPremiumUser ? 0.2 : 0.05;
const discount1 = basePrice * discountPercentage;
const finalPrice = basePrice - discount1;
console.log(finalPrice);
//8
const speed = 45;
const message = speed > 100 ? 'too fast' : 'OK';
const penality = speed > 100 ? 200 : 0;
console.log(message, penality);
//9
const role = 'student';
const isTeacher = role === 'teacher';
const dashboard = isTeacher ? 'gradebook' : 'courses';
const permissions = isTeacher ? 'view/edit/grade' : 'view';
console.log(dashboard, permissions);
//10
const age = 80;
const category = age >= 65 ? 'senior' : 'adult';
const ticketPrice = age >= 65 ? 5 : 10;
console.log(category, ticketPrice);

const sum = function (a, b) {
  return a + b;
}

const sub = function (a, b) {
  return a - b;
}

const mul = function (a, b) {
  return a * b;
}

const calculator = function (operator, firstElement, secondElement) {
  return operator(firstElement, secondElement);
}

console.log(calculator(sum, 54, 33));

let noOfTimes = 0;

function sort(data) {
  const sortedData = data.slice();
  for (let i = 0; i < data.length; i++) {
    for (let j = i + 1; j < data.length; j++) {
      noOfTimes++;
      if (sortedData[i] < sortedData[j]) {
        const element = sortedData[j];
        sortedData[j] = sortedData[i];
        sortedData[i] = element;
      }
    }
  }
  return sortedData;
}

// console.log((sort([1,2,3,3])));
// console.log(`\nnoOfTimes`,noOfTimes);
function randomNoBetween(lower, upper) {
  return Math.floor(Math.random() * (upper - lower)) + lower;
}

function randomArrayOfLength(length) {
  const randomArray = [];
  for (let index = 0; index < length; index++) {
    randomArray.push(randomNoBetween(0,100));
  }
  return randomArray;
}


function benchmark(lenghtOfArray) {
  noOfTimes = 0;
  sort(randomArrayOfLength(lenghtOfArray));
  return noOfTimes;
}

const lenghtOfArray = 4;

console.log(`benchmark of an array having length ${lenghtOfArray} is ${benchmark(4)}`);



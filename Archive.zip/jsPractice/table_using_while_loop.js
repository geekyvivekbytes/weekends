const num1 = 5
let count = 1
let result = 1
while (count <= 10) {
    result = count * num1;
    console.log(result);
    count = count + 1;
}


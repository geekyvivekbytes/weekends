function nthFibonnaciTerm(a) {
  let lastTerm = 0;
  let midTerm = 1;
  let currentTerm = 0;
  
  for (let term = 1; term <= a; term++) {
    lastTerm = midTerm;
    midTerm = currentTerm;
    currentTerm = lastTerm + midTerm;
  }
  return currentTerm;
}

function checkNthTerm(a, b) {
  const fibonnaciTerm = nthFibonnaciTerm(a);
  const verifyNthTerm = fibonnaciTerm === b;
  const resultInImage = verifyNthTerm ? "✅" : "❌";
  console.log(resultInImage, "output result is", fibonnaciTerm, "and expected result was", b);
}

checkNthTerm(1, 1);
checkNthTerm(2, 1);
checkNthTerm(5, 5);
checkNthTerm(7, 13);

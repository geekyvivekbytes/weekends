function factoiral(number) {
  let givenNumber = number;
  if (givenNumber === 0) {
    return 1;
  }
  return givenNumber * factoiral(givenNumber - 1);
}


function messageComposer(number, expectedResult, actualResult) {
  const verifyString = expectedResult === actualResult;
  const emoji = verifyString ? '✅' : '❌';
  let message = emoji + '[' + `${number}` + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + actualResult + '|';
  return message;
}
function checkFactorial(number, expectedResult) {
  const factoiralOfGivenNumber = factoiral(number);
  const message = messageComposer(number, expectedResult, factoiralOfGivenNumber);
  console.log(message);
}
function all() {
  checkFactorial(0, 1);
  checkFactorial(1, 1);
  checkFactorial(3, 6);
  checkFactorial(5, 120);
  checkFactorial(6, 720);
  checkFactorial(7, 5040);

}
all();
function reverseString(string, endIndex) {
  if (endIndex === 0) {
    return string[endIndex];
  }
  return string[endIndex] + reverseString(string, endIndex - 1);
}

function reverse(string) {
  if (string.length === 0) {
    return string;
  }
  let endIndex = string.length - 1;
  return reverseString(string, endIndex);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('helleh case', reverse('helleh'), 'helleh');
  test('hello case', reverse('hello'), 'olleh');
  test('empty string', reverse(''), '');
  test('one word', reverse('_'), '_');
}

runAllTests();
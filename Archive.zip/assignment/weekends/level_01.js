const river = ['🛶', '🌊', '🌊', '🌊', '🌊', '🌊', '🌊'];
const startSide = ['🐯', '🐮', '🍀', '🙎‍♂️'];
const endSide = [' ', ' ', ' '];
const dispay = [startSide, river, endSide];


function twiceJoin(array) {
  let lines = [];
  for (let index = 0; index < array.length; index++) {
    lines.push(array[index].join(' '));
  }
  return lines.join(' ');
}

function delay() {
  for (let i = 0; i < 100890000; i++) {
  }
}
function arrivalOfBoat() {
  for (let index = river.length - 1; index >= 1; index--) {
    river[index - 1] = river[index];
    river[index] = '🌊';
    console.clear();
    console.log(river.join(''));
    delay();
  }

}

function departureOfBoat() {
  for (let index = 0; index < river.length - 1; index++) {
    river[index + 1] = river[index];
    river[index] = '🌊';
    console.clear();
    console.log(river.join(''));
    delay();
  }
}

function sideArray(index) {
  const itemsContainer = [startSide, endSide];
  return itemsContainer[index % 2]
}

function updateOfMan() {
  let array = sideArray(index)
  const indexOfItem = '🙎‍♂️';
  array[indexOfItem] = '';
  sideArray(index + 1 % 2).push('🙎‍♂️');
}

function update(input, index) {
  if (input !== '') {
    let array = sideArray(index)
    const indexOfItem = array.indexOf(givenItems(input));
    array[indexOfItem] = '';
    sideArray(index + 1 % 2).push(givenItems(input));
    updateOfMan();
  }


}

function givenItems(input) {
  if (input !== '') {
    const items = 'tcl';
    const fixPositionOfItems = ['🐯', '🐮', '🍀'];
    return fixPositionOfItems[items.indexOf(input)]
  }
}

function isAvailable(input, index) {
  if (input !== '') {
    console.log('isavail', sideArray(index).includes(givenItems(input)));
    return sideArray(index).includes(givenItems(input));
  }
  return true

}

function whatIsInput(input) {

  for (let index = 0; index < 2; index++) {
    if ('tcl'.includes(input[index])) {
      return input[index];
    }
  }
  return '';
}

function isValidCondition(input, index) {
  return isAvailable(whatIsInput(input), index) && input.includes('m');
}

let index = 0;
function gameStart() {
  while (index <= 6) {

    console.log(twiceJoin(dispay));
    let userInput = prompt(`which item you want to take form ${index % 2} side`);
    console.log(userInput)
    if (!isValidCondition(userInput, index)) {
      console.log('enter valid data');
    } else {
      update(whatIsInput(userInput), index);
      console.clear();
      console.log(twiceJoin(dispay));
      index++;
    }
  }

}
gameStart();


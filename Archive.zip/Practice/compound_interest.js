function compoundInterest(p, r, t,) {
  if (t === 0 ) {
    return 0;
  }
  const simpleInterest = p * r / 100;
  return simpleInterest + compoundInterest(p + simpleInterest, r, t - 1);
}


function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('1st year', compoundInterest(100, 10, 1), 10);
  test('1st year', compoundInterest(100, 10, 2), 21);
  test('10th year', compoundInterest(1000, 10, 3), 331);
}

runAllTests();

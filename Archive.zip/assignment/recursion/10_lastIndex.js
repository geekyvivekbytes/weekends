function checkIndex(string, char, index) {
  if (string[index] === char) {
    return index;
  }
  if (index === 0) {
    return -1;
  }
  return checkIndex(string, char, index - 1);
}

function findLastIndex(string, char) {
  if (string === '' || char === '') {
    return -1;
  }
  const index = string.length - 1;
  return checkIndex(string, char, index);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('helleh case', findLastIndex('helleh', 'l'), 3);
  test('hello case', findLastIndex('hello', 'h'), 0);
  test('hello case', findLastIndex('hello', 'l'), 3);
  test('hello case', findLastIndex('hello', 'a'), -1);
  test('hello case', findLastIndex('hello', ''), -1);
  test('empty string', findLastIndex('', ''), -1);
  test('one word', findLastIndex('_', '_'), 0);
}

runAllTests();
// Write a function that gives first n elements of fibonacci in reverse order
// fibonacci(5) => [3, 2, 1, 1, 0]
// do not modify input parameters

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function reverseFibonacci(n) {
  let thirdLastTerm = 0;
  let secondLastTerm = 1;
  let currentTerm = 0;
  const reversedFibonacciTerms = [];
  for (let term = 1; term <= n; term++) {
    reversedFibonacciTerms.unshift(currentTerm);
    thirdLastTerm = secondLastTerm;
    secondLastTerm = currentTerm;
    currentTerm = thirdLastTerm + secondLastTerm;
  }
  return reversedFibonacciTerms;
}

function test(description, actual, expected) {
  if (areEqual(actual, expected)) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('first term', reverseFibonacci(1), [0]);
  test('first two term', reverseFibonacci(2), [1, 0]);
  test('first 3 term', reverseFibonacci(3), [1, 1, 0]);
  test('first 4 term', reverseFibonacci(4), [2, 1, 1, 0]);
  test('first 5 term', reverseFibonacci(5), [3, 2, 1, 1, 0]);
}
runAllTests();
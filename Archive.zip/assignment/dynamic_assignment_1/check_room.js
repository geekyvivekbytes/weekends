function passWords(sentence, Index) {
  for (let index = Index; index < sentence.length; index++) {
    let word = sentence[index];
    if ((word === ' ' || word === '\n' || word === '\t')) {
      return index;
    }
  }
}
function count(sentence) {
  let count = 0
  for (let index = 0; index < sentence.length; index++) {
    let word = sentence[index];
    if (!(word === ' ' || word === '\n' || word === '\t')) {
      count++;
      index = passWords(sentence, index);
    }
  }
  return count;
}


function isArmstrong(a) {
  let givenNumber = a;
  const auxilaryNumber = "" + a;
  const power = auxilaryNumber.length;
  let sum = 0;

  while (givenNumber > 0) {
    let digit = givenNumber % 10;
    givenNumber = (givenNumber - digit) / 10;
    sum = sum + (digit ** power);
  }
  return sum === a;
}

function checkIsArmstrong(a, b) {
  const result = isArmstrong(a);
  const isResultTrue = result === b;
  const resultInImage = isResultTrue ? "✅" : "❌";
  console.log(resultInImage, "output result is", result, "and expected result was", b);
}

checkIsArmstrong(153 , true);
checkIsArmstrong(34, false);
checkIsArmstrong(1, true);
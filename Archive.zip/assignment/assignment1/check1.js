function addition(a, b) {
  return a + b;
}

function multiply(a, b) {
  return a * b;
}

function divide(a, b) {
  return a / b;
}

function subtract(a, b) {
  return a - b;
}

function largestNumber(a, b) {
  return a > b ? a : b;
}

function isPrime(a) {
  return a % 2 === 0;
}

function printTable(a) {
  console.log("this is inside the printTable");
  for (let multiplier = 1; multiplier <= 10; multiplier++) {
    console.log(multiply(a, multiplier));
  }
}

function thirdLargestNumber(a, b, c) {
  console.log("this is inside of thirdLargestNumber");
  return largestNumber(a, largestNumber(b, c));
}

thirdLargestNumber();

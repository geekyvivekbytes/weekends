// let num = 65
// let num2 = 0
// let count = 0
// let gnum1 = 0
// let gnum2 = 1
// let remainder1 = 0
// let remainder2 = 0
// let remainder3 = 0

// while (  1 < num  ){
//     remainder1 = num % 2;
//     //console.log(remainder1);
//     num = (num - remainder1) /2;

//     remainder2 = num % 2;
//     //console.log(remainder2);
//     num2 = (num - remainder2) /2;

//     if (remainder2 === gnum1){
//         if (remainder1 === gnum2){
//             count = count + 1
//         }
//     }
    
// }
// //console.log(num);
// console.log('no of count is',count);
let num = 65
let auxremainder

while (num > 0){
    auxremainder = (num % 2 ===0);
    let remainder4 = auxremainder ? 0 : 1 ;
    num = num - remainder4;

    auxremainder1 = (num % 2 ===0);
    let remainder5 = auxremainder1 ? 0 : 1 ;
    console.log(remainder4);
    
}

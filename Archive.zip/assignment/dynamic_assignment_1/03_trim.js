/*
  Implement the below function to trim(remove all leading and trailing 
  whitespaces) from the given sentence.
  A whitespace is SPACE(" "), NEW LINE("\n"), TAB("\t")
  Examples:
  reverseString(" hello world\n") returns "hello world"
*/

function startIndex(sentence) {
  for (let index = 0; index < sentence.length; index++) {
    let word = sentence[index];
    if (!(word === ' ' || word === '\n' || word === '\t')) {
      return index;
    }
  }
}
function endIndex(sentence) {
  for (let index = sentence.length - 1; index >= 0; index--) {
    let word = sentence[index];
    if (!(word === ' ' || word === '\n' || word === '\t')) {
      return index;
    }
  }
}
function trim(sentence) {
  // Implementation here.
  let trimedString = ''
  let startingIndex = startIndex(sentence);
  let endingIndex = endIndex(sentence);
  for (let index = startingIndex; index <= endingIndex; index++) {
    trimedString = trimedString + sentence[index];
  }
  return trimedString;
}
function messageComposer(string, expectedResult, trimedString) {
  const verifyString = expectedResult === trimedString;
  const emoji = verifyString ? '✅' : '❌';
  let message = emoji + '[' + string + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + trimedString + '|';
  return message;
}
function checktTrim(sentence, expectedResult) {
  const trimedString = trim(sentence);
  const message = messageComposer(sentence, expectedResult, trimedString);
  console.log(message);
}
function all() {
  checktTrim(' rajesh ', 'rajesh');
  checktTrim("\nmohit ", 'mohit');
  checktTrim(' not found ', 'not found');
  checktTrim('  \n  hello    \t ', 'hello')
}
all();
function sumOfAP(a, d, n) {
  let sumOfAp = 0;
  let nthTerm = a;
  for (let term = 1; term <= n; term++) {
    sumOfAp = sumOfAp + nthTerm;
    nthTerm = nthTerm + d;
  }
  return sumOfAp;
}

function checkSumOfAp(a, d, n, e) {
  const sum = sumOfAP(a, d, n);
  const isSumTrue = sum === e;
  const resultInImage = isSumTrue ? "✅" : "❌";
  console.log(resultInImage, "output result is", sum, "and expected result was", e);
}

checkSumOfAp(1, 1, 10, 55);
checkSumOfAp(5, 10, 4, 80);
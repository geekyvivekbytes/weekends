// Do not rename p, t or r, use them as input for your program.
// While testing we will change their values.

const p = 3;
const t = 1;
const r = 2;

// Print the compound interest.
// Do not use compound interest formula to calculate the compound interest.
// Use simple interest formula and a loop to calculate the compound interest.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
let simpleInterest;
let amount = p;

for (let duration = 1; duration <= t; duration = duration + 1) {
  simpleInterest = (amount * r) / 100;
  amount = amount + simpleInterest;
}
const compoundInterest = amount - p;
console.log(compoundInterest);

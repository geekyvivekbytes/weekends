/*function fibonacciSeries(a) {
  let lastTerm = 0;
  let midTerm = 1;
  let currentTerm = 0;
  let allTerms = ''
  if (a > 0) {
    allTerms = allTerms + lastTerm + ' ';
  }
  for (let term = 1; a > term; term++) {
    lastTerm = midTerm;
    midTerm = currentTerm;
    currentTerm = lastTerm + midTerm;
    allTerms = allTerms + currentTerm + ' ';
  }
  return allTerms;
}*/

function nthFibonnaciTerm(a) {
  let lastTerm = 0;
  let midTerm = 1;
  let currentTerm = 0;
  for (let term = 1; a > term; term++) {
    lastTerm = midTerm;
    midTerm = currentTerm;
    currentTerm = lastTerm + midTerm;
  }
  return currentTerm;
}

function fibonacciSeries(a) {
  let allTerms = ''
  for (let term = 1; term <= a; term++) {
    allTerms = allTerms + nthFibonnaciTerm(term) + ' ';
  }
  return allTerms;
}

function checkFibonacciSeries(a, b) {
  const series = fibonacciSeries(a);
  const verifySeries = series === b;
  const resultInImage = verifySeries ? "✅" : "❌";
  console.log(resultInImage, "output result is", series, "and expected result was", b);
}

checkFibonacciSeries(1, "0 ");
checkFibonacciSeries(3, '0 1 1 ');
checkFibonacciSeries(7, '0 1 1 2 3 5 8 ');
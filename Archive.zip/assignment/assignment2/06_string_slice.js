/*
  Implement the below function that
  creates a slice/substring using start and end indices

  Examples:
    slice('hello world', 0, 4) => 'hello'
    slice('negative start', -1, 8) => 'negative '
    slice('', 0, 10) => ''

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function slice(text, start, end) {
  // Implementation here.
  let slicedStr = '';
  const sIndex = start < 0 ? 0 : start;
  const eIndex = end >= text.length ? text.length - 1 : end;
  for (let index = sIndex; index <= eIndex; index++) {
    slicedStr = slicedStr + text[index];
  }
  return slicedStr;
}
function isSlicingcorrect(text, start, end, expectedString) {
  const slicedString = slice(text, start, end);
  const isSlicedStrTrue = slicedString === expectedString;
  const emoji = isSlicedStrTrue ? "✅" : "❌";
  console.log(emoji, 'expected:', expectedString, 'actual:', slicedString);
}
function all() {
  isSlicingcorrect('made in India', 7, 18, ' India');
  isSlicingcorrect('negative start', -1, 8, 'negative ');
  isSlicingcorrect('unlimited fun', 9, 16, ' fun');
  isSlicingcorrect('', 0, 4, '');
  isSlicingcorrect('end is equal to length', 3, 22, ' is equal to length');
}
all();
let a = 'hello';
a = a.padStart
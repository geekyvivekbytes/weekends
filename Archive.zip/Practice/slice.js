function slice(string, start, end) {
  if (start === end) {
    return '';
  }
  return string[start] + slice(string, start)

}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('one character', isPalingram('a', 0, 1), "a");
  test('3 character', isPalingram('abcghi', 0, 3 ), 'cba');
}

runAllTests();

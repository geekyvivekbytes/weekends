const num = 5;
let result;
for (let sequence = 1 ; sequence < 11 ; sequence = sequence + 1) {
        result = sequence * num
        console.log(result);    
}


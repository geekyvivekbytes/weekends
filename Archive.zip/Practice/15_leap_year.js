function isleapYear(a) {
  let leapYear = a % 400 === 0 || (a % 4 === 0 && a % 100 !== 0);
  return leapYear;
}
 

function checkLeapYear(a, b) {
  const leapYear = isleapYear(a);
  const isTrueLeapYear = leapYear === b;
  const resultInImage = isTrueLeapYear ? "✅" : "❌";
  console.log(resultInImage, "output result is", leapYear, "and expected result was", b);
}

checkLeapYear(4040, true);
checkLeapYear(2100, false);
checkLeapYear(1900, false);
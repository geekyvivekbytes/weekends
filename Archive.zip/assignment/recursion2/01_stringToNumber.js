function numberToString(string, numberIndex, stringIndex) {
  if (string.length === stringIndex) {
    return 0;
  }
  const numbers = '0123456789';
  let number = 0;
  if (string[stringIndex] === numbers[numberIndex]) {
    stringIndex++;
    number = numberIndex;
    numberIndex = 0;
  }
  number = number * 10 ** (string.length - stringIndex)
  return number + numberToString(string, numberIndex + 1, stringIndex);
}

function stringToNumber(string) {
  // Implement code here
  const startFrom = 0;
  const stringIndex = 0;
  if (string[0] === '-') {
    return -1 * numberToString(string, startFrom, stringIndex + 1);
  }
  return numberToString(string, startFrom, stringIndex);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('0 as string', stringToNumber('0'), 0);
  test('test of 1222', stringToNumber("1222"), 1222);
  test('string with 1 only', stringToNumber('1'), 1);
  test('negative no as string', stringToNumber('-122'), -122);
  
}

runAllTests();

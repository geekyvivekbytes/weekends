const START_OF_LIST = 'l';
const START_OF_INTEGER = 'i'
const END_OF_INTEGER = 'e';
const END_OF_LIST = 'e';
const COLON = ':';


function isArray(x) {
  return typeof x === 'object';
}

function areArraysEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (!areDeepEqual(array1[index], array2[index])) {
      return false;
    }
  }

  return true;
}

function areDeepEqual(array1, array2) {
  if (typeof array1 !== typeof array2) {
    return false;
  }

  if (isArray(array1) && isArray(array2)) {
    return areArraysEqual(array1, array2);
  }

  return array1 === array2;
}



function arrayDecoder(array) {
  let encodedMessage = '';
  for (let index = 0; index < array.length; index++) {
    encodedMessage += encoder(array[index]);
  }
  return encodedMessage;
}

function encoder(input) {
  if (typeof (input) === "object") {
    return `${START_OF_LIST}${arrayDecoder(input)}${END_OF_LIST}`;
  }
  if (typeof (input) === "number") {
    return `${START_OF_INTEGER}${input}${END_OF_INTEGER}`;
  }
  return `${input.length}:${input}`
}
function nextIndexOf(target, string, cursorIndex) {
  return string.slice(cursorIndex).indexOf(target) + cursorIndex;
}

function decodeString(string, cursorIndex) {
  let index = nextIndexOf(COLON, string, cursorIndex) + 1;
  const lenghtOfStr = parseInt(string.slice(cursorIndex, index));
  const str = string.slice(index, lenghtOfStr + index);
  index += lenghtOfStr;
  return [str, index];
}

function decodeArray(encodedStr, cursorIndex) {
  let index = cursorIndex + 1;
  const decodedArray = [];
  while (index < encodedStr.length - 1 && encodedStr[index] !== END_OF_LIST) {
    const decodedStr = decode(encodedStr, index);

    decodedArray.push(decodedStr[0]);
    index = decodedStr[1];
  }
  return [decodedArray, index + 1];
}

function decodeInteger(encodedStr, index) {
  const indexOfend = nextIndexOf(END_OF_INTEGER, encodedStr, index);
  const strInteger = encodedStr.slice(index + 1, indexOfend);
  return [parseInt(strInteger), indexOfend + 1];
}

function decode(encodedStr, index = 0) {
  const startLetter = encodedStr[index];
  switch (startLetter) {
    case START_OF_INTEGER:
      return decodeInteger(encodedStr, index);
    case START_OF_LIST:
      return decodeArray(encodedStr, index);
    default:
      return decodeString(encodedStr, index);
  }
}

function decoder(encodedMessage) {
  return decode(encodedMessage)[0];
}

function test(description, actual, expected) {
  if (areDeepEqual(actual, expected)) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTest() {
  test('string', encoder('hello'), '5:hello');
  test('string', encoder(''), '0:');
  test('nested array', encoder(['hello', 45, [677, 777, [3412, 'hello']]]),
    'l5:helloi45eli677ei777eli3412e5:helloeee');
  test('empty array', encoder([]), 'le');
  test('numbers', encoder(7899), 'i7899e');
  test('zero', encoder(0), 'i0e');
  test('negative number', encoder(-34), 'i-34e');

  console.log(`\ndecoder\n`);

  test('only integer', decoder('i234e'), 234);
  test('negative integer', decoder("i-42e"), -42);
  test('string', decoder('5:hello'), 'hello');
  test('empty string', decoder('0:'), '');
  test('empty integer', decoder('i0e'), 0);
  test('nested array', decoder("lle5:applei123el6:bananai-5eee"),
    [[], "apple", 123, ["banana", -5]]);
  test('array with empty string and array as well as zero',
    decoder("l0:i0elee"), ["", 0, []]);


}

runAllTest();



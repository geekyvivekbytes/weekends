// Do not rename a, use them as input for your program.
// While testing we will change its values.

const a = 1690961;

// Print true if a is palindrome otherwise print false
// Printing more than one output or printing anything other than palindrome or not palindrome might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

// Print true if a is palindrome otherwise print false
// Printing more than one output or printing anything other than palindrome or not palindrome might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
let strNumber = "" + a;
let isPalindrome = true;

for (let index = 0; index < strNumber.length; index++) {
  const forwardDigit = strNumber[index];
  const reverseDigit = strNumber[strNumber.length - (1 + index)];
  const areDigitsEqual = forwardDigit === reverseDigit;
  isPalindrome = isPalindrome && areDigitsEqual;
}

console.log(isPalindrome);

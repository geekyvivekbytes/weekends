function primeNoInRange(a, b) {
  let allPrimes = ''

  for (let term = a; term <= b; term++) {
    let isComposite = false;
    for (let divisor = 2; divisor < term; divisor++) {
      let isComposite1 = term % divisor === 0;
      isComposite = isComposite || isComposite1;
    }
    let isPrime = !isComposite && term > 1;
    if (isPrime) {
      allPrimes = allPrimes + term + ' ';
    }
  }
  return allPrimes;
}
function checkPrimeFunction(a, b, c) {
  const primes = primeNoInRange(a, b);
  const isPrimesTrue = primes === c;
  const resultInImage = isPrimesTrue ? "✅" : "❌";
  console.log(resultInImage, "output result is", primes, "and expected result was", c);
}

checkPrimeFunction(0, 10, '2 3 5 7 ');
checkPrimeFunction(7, 30, '7 11 13 17 19 23 29 ');
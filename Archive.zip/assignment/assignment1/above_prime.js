// Do not rename a, use it as input for your program.
// While testing we will change its values.

const a = 13;

// Print the first prime number above a
// Printing more than one output or printing anything other than the first prime number above a might will be consider as error.
// Example: If a = 13, then the output should be 17

// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
let abovePrimeNo = a;
let findingPrime = true;
while (findingPrime) {
  abovePrimeNo = abovePrimeNo + 1;
  let isCompositeNumber = false;
  for (let divisor = 3; divisor < abovePrimeNo; divisor++) {
    let isDivisible = (abovePrimeNo % divisor === 0);
    isCompositeNumber = (isCompositeNumber || isDivisible);
  }
  if (!isCompositeNumber) {
    let primeNo = (abovePrimeNo <= 1) ? 2 : abovePrimeNo;
    console.log(primeNo);
    findingPrime = false;
  }
}

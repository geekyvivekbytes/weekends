/*
  Implement the below function to count the number of words
  in the given sentence.

  Rules:
  - A word is defined as a sequence of non-whitespace characters.
  - Whitespace includes SPACE(" "), TAB("\t"), and NEW LINE("\n").
  - Multiple consecutive whitespace characters should be treated
    as a single separator.
  - Leading and trailing whitespace should not affect the word count.

  Example:
  countWords("hello   \t   world \n test")
    -> 3
*/

function passWords(sentence, Index) {
  for (let index = Index; index < sentence.length; index++) {
    let word = sentence[index];
    if ((word === ' ' || word === '\n' || word === '\t')) {
      return index;
    }
  }
}
function countWords(sentence) {
  // Implementation here.
  let count = 0
  for (let index = 0; index < sentence.length; index++) {
    let word = sentence[index];
    if (!(word === ' ' || word === '\n' || word === '\t')) {
      count++;
      index = passWords(sentence, index);
    }
  }
  return count;
}
function messageComposer(string, expectedResult, countedWords) {
  const verifyCount = expectedResult === countedWords;
  const emoji = verifyCount ? '✅' : '❌';
  let message = emoji + '[' + string + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + countedWords + '|';
  return message;
}
function checkcountWords(sentence, expectedResult) {
  const countedWords = countWords(sentence);
  const message = messageComposer(sentence, expectedResult, countedWords);
  console.log(message);
}
function all() {
  checkcountWords("rajesh", 1);
  checkcountWords("mohit", 1);
  checkcountWords('not found', 2);
  checkcountWords('hello world', 2);
}
all();
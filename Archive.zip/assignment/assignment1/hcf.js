// Do not rename a or b, use them as input for your program.
// While testing we will change their values.

const a = 24;
const b = 48;

// Print the HCF of a and b
// Printing more than one output or printing anything other than HCF might will be consider as error.

// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
let hcf;
for (let divisor = 1; divisor <= a; divisor++) {
  if (a % divisor === 0 && b % divisor === 0) {
    hcf = divisor;
  }
}
console.log(hcf);  

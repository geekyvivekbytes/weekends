function fibonacciTerm(term, lastTerm, midTerm) {
  if (term === 1) {
    return midTerm;
  } 
  const currentTerm = lastTerm + midTerm;
  return fibonacciTerm(term - 1, midTerm, currentTerm);
}
function nthFibonacciTerm(n) {
  // Implement code here
  return fibonacciTerm(n, 1, 0);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  //test('0 as term', nthFibonacciTerm(0), 0);
  test('first term', nthFibonacciTerm(1), 0);
  test('2nd term', nthFibonacciTerm(2), 1);
  test('3rd term', nthFibonacciTerm(3), 1);
  test('5th term', nthFibonacciTerm(5), 3);
  test('7th term', nthFibonacciTerm(7), 8);
  test('8th term', nthFibonacciTerm(8), 13);
}

runAllTests();

let num1 = 21
let num2 = 32
const comparision1 = num1 < num2; // true
const comparision2 = num1 > num2; // false
let result = comparision1 ? comparision1 || comparision2 : comparision1 && comparision2 ;
let result2 = comparision2 ? comparision1 || comparision2 : comparision1 && comparision2 ;
console.log('Following are the result for using ternary ');

console.log(result ,'is the result of comparision1');
console.log(result2 , 'is the result of comparision2');
console.log(!result2 , 'is the result of comparision2 but as not gate');

// Write a function that gives first n elements of fibonacci in an array
// fibonacci(5) => [0, 1, 1, 2, 3]
// do not modify input parameters

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}

function fibonacci(n) {
  let thirdLastTerm = 0;
  let secondLastTerm = 1;
  let currentTerm = 0;
  const fibonacciSeries = [];
  for (let term = 1; term <= n; term++) {
    fibonacciSeries.push(currentTerm);
    thirdLastTerm = secondLastTerm;
    secondLastTerm = currentTerm;
    currentTerm = thirdLastTerm + secondLastTerm;
  }
  return fibonacciSeries;
}

function test(description, actual, expected) {
  if (areEqual(actual, expected)) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('first term', fibonacci(1), [0]);
  test('first two term', fibonacci(2), [0, 1]);
  test('first 3 term', fibonacci(3), [0, 1, 1]);
}
runAllTests();
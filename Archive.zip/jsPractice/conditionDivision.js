const divisor = 4;
const conditionDivior = 6;
const range = 100;
for(let auxdivisor = divisor ; auxdivisor <= range ; auxdivisor = auxdivisor + 4 ){
    let case1 = auxdivisor % divisor === 0;
    let case2 = auxdivisor % conditionDivior === 0;
    if ( case1 && !case2){
        console.log(auxdivisor);
        
    }

}
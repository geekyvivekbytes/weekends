// Given array1 and array2, returns true if both arrays are deeply equal, else false.
// Deep equality means both arrays contain the same elements in the same order,
// including any nested arrays, which must also be deeply equal.
// Examples:
// areDeepEqual([1, 2, 3], [1, 2, 3]) => true
// areDeepEqual([1, [2, 3]], [1, [2, 3]]) => true
// areDeepEqual([1, [2, 3]], [1, [3, 2]]) => false
// areDeepEqual([1, 2], [1, 2, 3]) => false
// areDeepEqual([1, [2, [3]]], [1, [2, [3]]]) => true
// areDeepEqual([1, [2, [3]]], [1, [2, 3]]) => false
// do not modify input parameters


function isItObjectType(array1, array2) {
  return typeof (array1) === typeof (array2) === 'object';
}

function areDeepEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    const elementOfArray1 = array1[index];
    const elementOfArray2 = array2[index];

    if (isItObjectType(elementOfArray1, elementOfArray2)) {
      if (!areDeepEqual(elementOfArray1, elementOfArray2)) {
        return false;
      }
    }
    if (typeof (elementOfArray1) !== 'object' && elementOfArray1 !== elementOfArray2) {
      return false;
    }
  }
  return true;
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('equal array', areDeepEqual([1, 2, 3, 4], [1, 2, 3, 4]), true);
  test('unequal array but 2nd has same and extra elements', areDeepEqual([1, 2, 3, 4], [1, 2, 3, 4, 5, 6]), false);
  test('equal but empty array', areDeepEqual([], []), true);
  test('equal length but with different nested array', areDeepEqual([1, [2, 3]], [1, [3, 2]]), false);
  test('nested with one array', areDeepEqual([1, [2, 3]], [1, [2, 3]]), true);
  test('array indside nested array', areDeepEqual([1, [2, [3]]], [1, [2, [3]]]), true);
  test('array with different nesting', areDeepEqual([1, [2, 3]], [1, [2, [3]]]), false);
  test('array indside nested array follow by array', areDeepEqual([1, [2, [3]], [4]], [1, [2, [3]], [4]]), true);
}
runAllTests();
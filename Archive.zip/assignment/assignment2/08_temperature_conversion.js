
/*
  Write a function that converts temperature from one unit to another

  Function takes three arguments: `from`, `to`, `value`
  
  `from` and `to` can have following values:
    - C
    - F
    - K

  Here C means Celsius, K is Kelvin and F is Fahrenheit

  Examples:
    convert('C', 'K', 0) => 273.15
    convert('C', 'F', 37) => 98.6
    convert('F', 'K', 98.6) => 310.15
    convert('F', 'C', -40) => -40
    convert('K', 'C', 100) => -173.15
    convert('K', 'F', 100) => -279.67

  Here are the conversion formulae in case you wonder how it is done :)
    - F to C:
      (F − 32) × 5/9 = C
    - K to C:
      K − 273.15 = C

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function CtoF(value) {
  return (value * 9 + 160) / 5;
}
function FtoC(value) {
  return (value - 32) * 5 / 9;
}
function CtoK(value) {
  return value + 273.15;
}
function KtoC(value) {
  return value - 273.15;
}
function convert(from, to, value) {
  // Implementation here.
  const scaleName = from + to;
  let inputTemp = value;
  inputTemp = inputTemp * 1;
  switch (scaleName) {
    case 'FC':
      return FtoC(inputTemp);
    case 'CF':
      return CtoF(inputTemp);
    case 'CK':
      return CtoK(inputTemp);
    case 'KC':
      return KtoC(inputTemp);
    case 'FK':
      const celsius = FtoC(inputTemp);
      return CtoK(celsius);
    case 'KF':
      const cels = KtoC(inputTemp);
      return CtoF(cels);
    case 'CC':
      return inputTemp;
    case 'FF':
      return inputTemp;
    case 'KK':
      return inputTemp;
    default:
      return NaN;
  }
}
function isApproximate(returnValue, expectedValue) {
  const tolerence1 = returnValue - expectedValue;
  const tolerence2 = expectedValue - returnValue;
  const tolerence = returnValue > expectedValue ? tolerence1 : tolerence2;
  return 0.05 > tolerence;
}
function checkConversion(from, to, value, expectedValue) {
  const returnValue = convert(from, to, value);
  const emoji = isApproximate(returnValue, expectedValue) ? "✅" : "❌";
  console.log(emoji, 'expected:', expectedValue, 'actual:', returnValue);
}
function all() {
  checkConversion('F', 'C', 104, 40);
  checkConversion('F', 'K', 1, 255.92);
  checkConversion('C', 'F', 98, 208.4);
  checkConversion('C', 'K', 85, 358.15);
  checkConversion('K', 'C', 458, 184.85);
  checkConversion('K', 'F', 48, -373.27);
  checkConversion('D', 'L', 199, NaN);
  checkConversion('K', 'C', 'D', NaN);
}
all();
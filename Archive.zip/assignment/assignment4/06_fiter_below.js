// Given an array of numbers and a threshold value, return a new array
// that contains all the numbers which are below threshold.
// filterBelow([6, 2, 3, 1, 4, 7], 3) => [2, 1]
// filterBelow([1, 2, 3], 0) => []
// do not modify input parameters

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }
  
  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }
  return true;
}
function filterBelow(array, threshold) {
  const valuebelowThreshold = [];
  for (let index = 0; index < array.length; index++) {
    if (array[index] < threshold) {
      valuebelowThreshold.push(array[index]);
    }
  }
  return valuebelowThreshold;
}

function test(description, actual, expected) {
  if (areEqual(actual, expected)) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('singleton array', filterBelow([1], 1), []);
  test('4 length array', filterBelow([4, 3, 2, 1], 3), [2, 1]);
  test('4 length array', filterBelow([4, 3, 2, 1], 7), [4, 3, 2, 1]);
  test('empty array', filterBelow([], 0), []);
}
runAllTests();
function checkPalindrome(sentence, startIndex, endIndex) {
  if (sentence[startIndex] !== sentence[endIndex]) {
    return false;
  }
  if (endIndex === 0) {
    return true;
  }
  return checkPalindrome(sentence, startIndex + 1, endIndex - 1);
}

function isPalindrome(palindromeCandidate) {
  const startIndex = 0;
  const endIndex = palindromeCandidate.length - 1;
  if (startIndex === endIndex || palindromeCandidate.length === 0) {
    return true;
  }
  return checkPalindrome(palindromeCandidate, startIndex, endIndex);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('helleh case', isPalindrome('helleh'), true);
  test('hello case', isPalindrome('hello'), false);
  test('empty string', isPalindrome(''), true);
  test('one word', isPalindrome('_'), true);
}

runAllTests();
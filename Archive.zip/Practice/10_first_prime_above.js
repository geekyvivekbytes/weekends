function primeAbove(a) {
  let givenNumber = a;
  let findingPrime = true;
  while (findingPrime) {
    givenNumber = givenNumber + 1;
    let isCompositeNumber = false;
    for (let divisor = 2; divisor < givenNumber; divisor++) {
      let isCompNum = givenNumber % divisor === 0;
      isCompositeNumber = isCompositeNumber || isCompNum;
    }
    if (!isCompositeNumber) {
      let primeNo = (givenNumber === 1) ? 2 : givenNumber;
      findingPrime = false;
      return primeNo;
    }
  }
}

function checkPrimeAbove(a, b) {
  const foundedPrimeNo = primeAbove(a);
  const isActualNo = foundedPrimeNo === b;
  const resultInImage = isActualNo ? "✅" : "❌";
  console.log(resultInImage, "output result is", foundedPrimeNo, "and expected result was", b);
}

checkPrimeAbove(3, 5);
checkPrimeAbove(95, 97);
checkPrimeAbove(25, 29);
checkPrimeAbove(0, 2);
checkPrimeAbove(1, 2);
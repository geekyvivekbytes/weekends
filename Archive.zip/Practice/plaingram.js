function countCharacter(string, target, index) {
  if (index === string.length) {
    return 0;
  }
  let count = 0;
  if (string[index] === target) {
    count++;
  }
  return count + countCharacter(string, target, index + 1);
}

function checkPalingram(string, string2, index) {
  if (string.length !== string2.length) {
    return false;
  }
  if (string.length === index) {
    return true;
  }
  const sameCharacterInString = countCharacter(string, string[index], 0);
  const sameCharacterInString2 = countCharacter(string2, string[index], 0);

  if (sameCharacterInString !== sameCharacterInString2) {
    return false;
  }
  return true && checkPalingram(string, string2, index + 1);
}

function isPalingram(string, string2) {

  return checkPalingram(string, string2, 0);
}


function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('one character', isPalingram('a', 'a'), true);
  test('3 character', isPalingram('abc', 'cba'), true);
  test('6 character', isPalingram('aabbcc', 'abcabc'), true);
  test('non palingram', isPalingram('' ,''), true);

}

runAllTests();

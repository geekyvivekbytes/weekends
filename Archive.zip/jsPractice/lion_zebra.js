const situation = ' L   ZZ L';
let result = 0;

for(let stringIndex = 0;stringIndex < situation.length  ; stringIndex++) {

    let forLionCondition = situation[stringIndex]=== 'L';
    let forZebraCondition = situation[stringIndex]=== 'Z';
    
    let forIndxeStorage = stringIndex;
    let IndexForOtherLoop = stringIndex;
    
    if (forLionCondition){
        for(;IndexForOtherLoop < situation.length; IndexForOtherLoop++){
            let check1 = (situation[IndexForOtherLoop] === 'Z');
            if (check1){
                if (result === 0){
                    result = (IndexForOtherLoop - forIndxeStorage);
                    
                }else{
                    result = ( IndexForOtherLoop - forIndxeStorage ) > result ? result : (IndexForOtherLoop - forIndxeStorage);
                    
                }
            }   
        }
        
    }
       
       if (forZebraCondition){
           for (;IndexForOtherLoop < situation.length; IndexForOtherLoop++){
               let check2 = (situation[IndexForOtherLoop] === 'L')
               if (check2){
                   if (result === 0){
                       result = (IndexForOtherLoop - forIndxeStorage);
                       
                    }else{
                        result = ( IndexForOtherLoop - forIndxeStorage ) > result ? result : (IndexForOtherLoop - forIndxeStorage);

                    }
                }    
                
           }
            
        }
}
    
result = result - 1
console.log(result);
    

// Given an array of numbers and a element, return the last index in the array
// where element is present else -1
// findLastIndex(["apple", "cake", "tea", "coffee", "tea", "pen"], "tea") => 4
// do not modify input parameters

function findLastIndex(array, element) {
  for (let index = array.length - 1; index >= 0; index--) {
    if (array[index] === element) {
      return index;
    }
  }
  return -1;
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('array with 4 element', findLastIndex([2, 3, 3, 3], 3), 3);
  test('array with 0 element', findLastIndex([], 3), -1);
  test('array not have require element', findLastIndex([0, 4, 2], 3), -1);
  test('elements are string', findLastIndex(["egg", "cake", "tea", "tea"], "tea"), 3);
}
runAllTests();
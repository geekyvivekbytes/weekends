function checkPrime(a) {
  let isPrime = false;
  for (let divisor = 2; divisor < a; divisor++) {
    let result1 = a % divisor === 0;
    isPrime = isPrime || result1;
  }
  isPrime = (a <= 1) ? isPrime : !isPrime;
  return isPrime;

}

function verifyPrime(a, b) {
  const isPrime = checkPrime(a);
  const isTruePrime = isPrime === b;
  const resultInImage = isTruePrime ? "✅" : "❌";
  console.log(resultInImage, "output result is", isPrime, "and expected result was", b);

}
verifyPrime(0, false);
verifyPrime(1, false);
verifyPrime(97, true);
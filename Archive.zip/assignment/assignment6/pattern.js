
function makeARow(length, symbol = '*', spaceLength = 0) {
  if (spaceLength <= 0) {
    return symbol.repeat(length);
  }
  return symbol + ' '.repeat(spaceLength) + symbol;
}

function selectChar(character, index) {
  return character[index % character.length];
}

function makeRectangle(length, breadth, char = '*') {
  const formedPattern = [];

  for (let index = 0; index < breadth; index++) {
    const line = makeARow(length, selectChar(char, index));
    formedPattern.push(line);
  }

  return formedPattern;
}

function makeHollowRectangle(length, breadth) {
  let formedPattern = [];
  const filledLine = (makeARow(length));
  formedPattern.push(filledLine);

  for (let index = 2; index < breadth; index++) {
    formedPattern.push(makeARow(length, "*", length - 2));
  }

  if (breadth !== 1) {
    formedPattern.push(filledLine);
  }
  return formedPattern;
}

function makeTriangle(length, padLength = 0) {
  let formedTriangle = [];

  for (let index = 1; index <=length; index++) {
    const line = makeARow(index);
    formedTriangle.push(line.padStart(padLength));
  }

  return formedTriangle;
}

function rowLength(value, range) {
  let reqOutput = value * 2 + 1;
  if (reqOutput > range) {
    reqOutput = range * 2 - reqOutput;
  }
  return reqOutput;
}

function padLength(length, line) {
  return ((length - line.length) / 2 + line.length);
}

function paddedString(diamondString, length) {
  return diamondString.padStart(padLength(length, diamondString));
}

function hollowDiamondRow(index, length) {
  const rowLen = rowLength(index, length);
  return makeARow(rowLen, "*", rowLen - 2);
}

function makeHollowDiamond(length) {
  length = length - (length + 1) % 2;
  const formedStructure = [];

  for (let index = 0; index < length; index++) {
    let line = hollowDiamondRow(index, length);
    line = paddedString(line, length);
    formedStructure.push(line);
  }
  return formedStructure;
}

function makeDiamond(length) {
  length = length - (length + 1) % 2;
  const formedDiamond = [];

  for (let index = 0; index < length; index++) {
    let line = makeARow(rowLength(index, length));
    line = paddedString(line, length);
    formedDiamond.push(line);
  }

  return formedDiamond;
}

function selectPattern(style, length, breadth) {
  switch (style) {
    case 'filled-rectangle':
      return makeRectangle(length, breadth);
    case "hollow-rectangle":
      return makeHollowRectangle(length, breadth);
    case "alternating-rectangle":
      return makeRectangle(length, breadth, '*-');
    case "spaced-alternating-rectangle":
      return makeRectangle(length, breadth, '*- ');
    case "triangle":
      return makeTriangle(length);
    case "right-aligned-triangle":
      return makeTriangle(length, length);
    case "diamond":
      return makeDiamond(length);
    case "hollow-diamond":
      return makeHollowDiamond(length);
  }
  
}

function generatePattern(style, dimensions) {
  // implement this
  const length = dimensions[0];
  const breadth = dimensions[1];
  if (length === 0 || breadth === 0) {
    return '';
  }
  const lines = selectPattern(style, length, breadth);
  
  return lines.join('\n');
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function testDiamond() {
  console.log('\n', 'diamonds', '\n');

  test('hollow diamond', generatePattern("hollow-diamond", [5]),
   '  *\n * *\n*   *\n * *\n  *');
   test('diamond', generatePattern("diamond", [5]),
   '  *\n ***\n*****\n ***\n  *');
}

function testRectangle() {
  console.log('\n', 'rectangle', '\n');

  test('1 x 1 rectangle', generatePattern('filled-rectangle', [1, 1]), '*');
  test('1 x 0 rectangle', generatePattern('filled-rectangle', [1, 0]), '');
  test('0 x 2 rectangle', generatePattern('filled-rectangle', [0, 2]), '');

  console.log('\n', 'hollow-rectangle', '\n');

  test('2 x 2 rectangle', generatePattern('hollow-rectangle', [2, 2]),
    '**\n**');
  test('2 x 2 rectangle', generatePattern('hollow-rectangle', [1, 2]), '*\n*');
  test('4 x 5 rectangle', generatePattern('hollow-rectangle', [4, 5]),
    '****\n*  *\n*  *\n*  *\n****');
  test('5 x 1 rectangle', generatePattern('hollow-rectangle', [5, 1]),
    '*****');
  test('1 x 1 rectangle', generatePattern('hollow-rectangle', [1, 1]), '*');
  test('1 x 2 rectangle', generatePattern('hollow-rectangle', [1, 2]), '*\n*');
}

function runAllTests() {
  testRectangle(); 
  console.log('\n', 'alternating-rectangle', '\n');

  test('1 x 1 rectangle', generatePattern('alternating-rectangle', [1, 1]),
    '*');
  test('3 x 6 rectangle', generatePattern('alternating-rectangle', [3, 6]),
    '***\n---\n***\n---\n***\n---');

  console.log('\n', "spaced-alternating-rectangle", '\n');

  test('simple case', generatePattern("spaced-alternating-rectangle",
    [2, 3]), '**\n--\n  ');
  test('simple case', generatePattern("spaced-alternating-rectangle",
    [4, 3]), '****\n----\n    ');

  console.log('\n', "triangle", '\n');

  test('triangle case', generatePattern('triangle', [3]), '*\n**\n***');
  test('right angled triangle', generatePattern("right-aligned-triangle", [5]),
  '    *\n   **\n  ***\n ****\n*****');

  testDiamond();
}
runAllTests();
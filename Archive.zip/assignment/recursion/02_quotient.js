function quotient(dividend, divisor) {
  let givenDividend = dividend;
  if (divisor === 0) {
    return 'infinity';
  }
  if (dividend < divisor || dividend === 0) {
    return 0;
  }
  givenDividend = givenDividend - divisor;
  return 1 + quotient(givenDividend, divisor);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('divisor and dividend are 0', quotient(0, 0), 'infinity');
  test('only dividend is 0', quotient(0, 5), 0);
  test('only divisor is 0', quotient(5, 0), 'infinity');
  test('both divisor and dividend are positive', quotient(45, 9), 5);
}

runAllTests();

function sumOfAP(a, d, n) {
  // Implement code here
  if (n === 0) {
    return 0;
  }
  let nTerm = a + (n - 1) * d;
  return nTerm + sumOfAP(a, d, n - 1);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('0 term', sumOfAP(3, 4, 0), 0);
  test('1st term', sumOfAP(3, 4, 1), 3);
  test('10th term', sumOfAP(1, 1, 10), 55);
}

runAllTests();

function factorial(a) {
  let factorialOfNumber = 1;
  for (let term = a; term > 0; term--) {
    factorialOfNumber = factorialOfNumber * term;
  }
  return factorialOfNumber;
}

function factorialTest(a, b) {
  const factorialOFNumber = factorial(a);
  const isFactorialTrue = factorialOFNumber === b;
  const resultInImage = isFactorialTrue ? "✅" : "❌";
  console.log(resultInImage, "output result is", factorialOFNumber, "and expected result was", b);
}

factorialTest(5, 120);
factorialTest(0, 1);
factorialTest(7, 5040);
factorialTest(6, 720);

function sumOfGP(firstTerm, ratio, nThTerm) {
  if (nThTerm === 0 ) {
    return 0;
  }
  const nTerm = firstTerm * (ratio ** (nThTerm - 1));
  return nTerm + sumOfGP(firstTerm, ratio, nThTerm - 1); 
}

function checkSumOfGp(a, d, n, e) {
  const sum = sumOfGP(a, d, n);
  const isSumTrue = sum === e;
  const resultInImage = isSumTrue ? "✅" : "❌";
  console.log(resultInImage, "output result is", sum, "and expected result was", e);
}

checkSumOfGp(1, 1, 10, 10);
checkSumOfGp(1, 1, 1, 1);
const num1 = 2;
const num2 = 5;
const num3 = 8;
let check = (num1 > num2) ? num1 : num2 ;
let result = (check > num3) ? check : num3;
console.log(result)





function sqrRoot(a) {
  const squareRoot = a ** 0.5;
  return squareRoot;
}

function isApproximate(a, b) {
  const tolerence1 = a - b;
  const tolerence2 = b - a;
  const tolerence = a > b ? tolerence1 : tolerence2;
  return 0.05 > tolerence;
}

function isSquareRoot(a, b) {
  const squareRoot = sqrRoot(a);
  const resultInImage = isApproximate(squareRoot, b) ? "✅" : "❌";
  console.log(resultInImage, "output result is", squareRoot, "and expected result was", b);
}

isSquareRoot(2, 1.414);
isSquareRoot(3, 1.732);
isSquareRoot(16, 4);
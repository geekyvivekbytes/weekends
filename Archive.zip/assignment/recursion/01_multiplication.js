function multiply(multiplier, multiplicand) {
  if (multiplier === 0) {
    return 0;
  }
  return multiplicand + multiply(multiplier - 1, multiplicand);
}

function messager(multiplier, multiplicand, expectedResult, actualResult) {
  const verifyResult = expectedResult === actualResult;
  const emoji = verifyResult ? '✅' : '❌';
  let message = emoji + '[' + multiplier + ':' + multiplicand + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + actualResult + '|';
  return message;
}

function checkMultipy(multiplier, multiplicand, expected) {
  const actualResult = multiply(multiplier, multiplicand);
  const message = messager(multiplier, multiplicand, expected, actualResult);
  console.log(message);
}

function all() {
  checkMultipy(0, 0, 0);
  checkMultipy(0, 5, 0);
  checkMultipy(5, 0, 0);
  checkMultipy(5, 6, 30);
  checkMultipy(6, 4, 24);
}
all();
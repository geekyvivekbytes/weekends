let num1 = 55;
let num2 = 45;
console.log( 'sum =', num1 + num2);
console.log('subtraction =',num1 - num2);
console.log('multiplication =', num1 * num2);
console.log('division = ', num1 / num2);

console.log(((num1 < num2) && (num2 < num )) ? num1 = num1 + num1 : num2 = num2 + num2);

function issubstring(string, substring, stringIndex) {
  for (let index = 0; index < substring.length; index++) {
    if (string[stringIndex] !== substring[index]) {
      return 0;
    }
    stringIndex++;
  }
  return 1;
}

function findIndex(string, substring) {
  for (let index = 0; index < string.length; index++) {
    if (string[index] === substring[0]) {
      return index;
    }
  }
}

function countSubstring(string, substring) {
  let count = 0
  let times = 0
  while (times < string.length) {
    let stringIndex = findIndex(string, substring);
    count += issubstring(string, substring, stringIndex);
    times++;
  }
  return count;
}

console.log(countSubstring('hahahaha', 'haha'));

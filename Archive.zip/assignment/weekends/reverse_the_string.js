function lastSpace(string, startIndex) {
  if (string[startIndex] === ' ' || startIndex === 0) {
    return startIndex;
  }
  return lastSpace(string, startIndex - 1 );
}
function printFromLast(string, startIndex, endIndex) {
  if (startIndex === endIndex - 1) {
    return string[startIndex];
  }
  return string[startIndex] + printFromLast(string, startIndex + 1, endIndex);
}

function semiReverseString(string, startIndex = 0, endIndex = 0) {
  if (string === '') {
    return '';
  }
  if (endIndex === 0) {
    endIndex = string.length;
  }
  
  startIndex = lastSpace(string, endIndex - 1);
  
  if (startIndex === 0) {
    return printFromLast(string, startIndex, endIndex);
  }
  let splitedString = printFromLast(string, startIndex, endIndex) + ' ';
  splitedString += semiReverseString(string, endIndex, startIndex);
  return printFromLast(splitedString, 1, splitedString.length)
}

let a = semiReverseString('f un');
console.log(a);
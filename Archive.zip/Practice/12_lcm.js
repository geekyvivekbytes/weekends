function findLCM(a, b) {
  let largestNumber = (a > b) ? a : b;
  let lcm;
  let findingLCM = true;

  while (findingLCM) {
    if (largestNumber % a === 0 && largestNumber % b === 0) {
      lcm = largestNumber;
      findingLCM = false;
    }
    largestNumber++;
  }
  return lcm;
}

function checkLCM(a, b, c) {
  const lcm = findLCM(a, b);
  const isLCMTrue = lcm === c;
  const resultInImage = isLCMTrue ? "✅" : "❌";
  console.log(resultInImage, "output result is", lcm, "and expected result was", c);
}

checkLCM(2, 4, 4);
checkLCM(4, 7, 28);
checkLCM(8, 9, 72);
function evenNoInGivenRange(a, b) {
  let evenNo = "";
  for (let term = a; term <= b; term = term + 1) {
    if (term !== 0 && term % 2 === 0) {
      evenNo = evenNo + term + " ";
    }
  }
  return evenNo;
}

function isOutputTrue(a, b, c) {
  const evenOutput = evenNoInGivenRange(a, b);
  const checkWithExpected = evenOutput === c;
  const resultInImage = checkWithExpected ? "✅" : "❌";
  console.log(
    resultInImage,
    "output result is",
    evenOutput,
    "and expected result was",
    c,
  );
}

isOutputTrue(10, 24, "10 12 14 16 18 20 22 24 ");
isOutputTrue(0, 10, "2 4 6 8 10 ");
isOutputTrue(-6, 0, "-6 -4 -2 ");

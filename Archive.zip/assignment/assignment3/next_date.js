/**
 * Implement the `nextDate` function below. Given a date in the format dd-mm-yyyy, 
 * it should return the next date in the same format.
 * 
 * The input date will always follow the dd-mm-yyyy format. 
 * This means the first two characters will be digits for the day (e.g., 01, 23), 
 * followed by a hyphen (-), the next two characters will be digits for the month (e.g., 01, 12), 
 * followed by another hyphen, and the remaining four characters will be digits for the year 
 * (any year between 0000 and 9999).
 * 
 * In case of an invalid date (with correct format dd-mm-yyyy), for example, "32-02-2025", 
 * return "Invalid Date".
 */

function changeMonth(date, month, day) {
  day = '01';//wrong way

  if (month === 12) {
    month = '01';
    
    let year = parseInt(date.slice(-4));
    year = (year + 1) + '';
    year = year.padStart(4, '0');//type coercion 

    return `${day}-${month}-${year}`;
  }
  month = '' + (month + 1);
  month = month.padStart(2, '0');//type coercion
  return `${day}-${month}${date.slice(-5)}`;
}

function changeDay(date, day) {
  day = (day + 1) + '';
  day = day.padStart(2, '0');
  return day + date.slice(-8);
}

function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0 || year % 400 === 0);
}

function feburary(date, month, day) {//fn name
  const year = parseInt(date.slice(-4));
  const daysLimit = 29;
  if (isLeapYear(year) && day <= 29) {
    return simpleMonth(date, month, day, daysLimit);
  }
  
  if (day <= 28) {
    return simpleMonth(date, month, day, daysLimit - 1);
  }
  return 'Invalid Date';
}

function simpleMonth(date, month, day, totalNoOfDays) {
  if (day > totalNoOfDays) {
    return 'Invalid Date';
  }
  if (day === totalNoOfDays) {
    return changeMonth(date, month, day);
  }
  return changeDay(date, day);
}

function lastMonth(date, month, day) { 
  const year = parseInt(date.slice(-4));

  if ((day === 31 && year === 9999) || day > 31) {
    return 'Invalid Date';
  }

  const totalNoOfDays = 31;

  return simpleMonth(date, month, day, totalNoOfDays);
}

function nextDate(date) {
  const day = parseInt(date.slice(0, 2));
  const month = date.slice(3, 5);
  const allZero = date.slice(-4) === '0000' || month === '00' || day === 0 ;

  if (parseInt(month) > 12 || allZero) {
    return 'Invalid Date';
  }
  if (month === '12') {
    return lastMonth(date, parseInt(month), day);
  }
  if (month === '02') {
    return feburary(date, parseInt(month), day);
  }

  const calendarMonth = '0103050708';//naming knuckleMonths
  const noOfDays = 31;

  if (calendarMonth.includes(month)) {
    return simpleMonth(date, parseInt(month), day, noOfDays);
  }
  return simpleMonth(date, parseInt(month), day, noOfDays - 1);
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('Simple increment of a normal day', nextDate('15-03-2021'), '16-03-2021');
  test('Given date, Month, Year are 0', nextDate('00-00-0000'), "Invalid Date");
  test('Checking for the first day of calendar', nextDate('01-01-0001'), '02-01-0001');
  test('Date is 0 ', nextDate('00-11-2025'), "Invalid Date");
  test('Month section Contains 0', nextDate('23-00-2342'), "Invalid Date");
  test('Only year is 0', nextDate('12-05-0000'), "Invalid Date");
  test('Date is exceed for Months having 31 days like January', nextDate('32-01-2024'), "Invalid Date");
  test('Date is exceed for the Months having 30 days like April', nextDate('31-04-2024'), "Invalid Date");
  test('Month exceed than 12', nextDate('01-13-2024'), "Invalid Date");
  test('In Leap Year end of February Month change', nextDate('29-02-2024'), '01-03-2024');
  test('Non Leap Year February month', nextDate('29-02-2026'), "Invalid Date");
  test('Year seems like Leap Year', nextDate('29-02-1900'), "Invalid Date");
  test('Change in year', nextDate('31-12-2024'), '01-01-2025');
  test('August case as it has 31 days(two month have 31 days simultaneously)', nextDate('31-08-2024'), '01-09-2024');
  test("last day of calendar", nextDate("31-12-9999"), "Invalid Date");
  test("Simple increment of 29th February(02nd month) in a leap year", nextDate("28-02-2024"), "29-02-2024");
  test("Simple increment of a normal day in December(12th month)", nextDate("25-12-2024"), "26-12-2024");
  test("Simple increment of a day more than 31", nextDate("32-10-2024"), "Invalid Date");
  test("Simple increment of a day more than 31", nextDate("32-12-2024"), "Invalid Date");
  test("Simple increment of a day more than 12th month", nextDate("14-13-2024"), "Invalid Date");
  test("Simple increment of 30th February(02nd month) in a year", nextDate("30-02-2024"), "Invalid Date");
}
runAllTests();
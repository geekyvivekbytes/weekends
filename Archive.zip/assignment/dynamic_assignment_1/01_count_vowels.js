/*
  Implement the below function to count number of vowels present in the
  give sentence.
  Examples:
  countVowels("hello world") returns 3
  countVowels("hEllo wOrld") returns 3
*/

function isVowels(words) {
  const vowels = 'aeiouAEIOU';
  for (let index = 0; index < vowels.length; index++) {
    if (vowels[index] === words) {
      return 1;
    }
  }
  return 0;
}
function countVowels(sentence) {
  // Implementation here.
  let count = 0;
  for (let index = 0; index < sentence.length; index++) {
    count = count + isVowels(sentence[index])
  }
  return count;
}
function messageComposer(string, expectedResult, noOfvowelsFound) {
  const verifyCount = expectedResult === noOfvowelsFound;
  const emoji = verifyCount ? '✅' : '❌';
  let message = emoji + '[' + string + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + noOfvowelsFound + '|';
  return message;
}
function checkcountVowels(sentence, expectedResult) {
  const noOfvowelsFound = countVowels(sentence);
  const message = messageComposer(sentence, expectedResult, noOfvowelsFound);
  console.log(message);
}
function all() {
  checkcountVowels('rajesh', 2);
  checkcountVowels("mohit", 2);
  checkcountVowels('not found', 3);
  checkcountVowels('hello world', 3);
  checkcountVowels('repeating iiiiiiii', 12);
  checkcountVowels('not found', 3);
  checkcountVowels("hello world", 3);
  checkcountVowels("hEllo wOrld", 3);
}
all();
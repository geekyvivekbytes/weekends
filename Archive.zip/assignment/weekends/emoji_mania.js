const tube1 = ['|','⚪️','|','  ','|','  ','|','  ','|','  ','|'];
const tube2 = ['|','⭕️','|','  ','|','  ','|','  ','|','  ','|'];
const tube3 = ['|','  ','|','  ','|','  ','|','  ','|','  ','|'];
const tube4 = ['|','  ','|','  ','|','  ','|','  ','|','  ','|'];
const tube5 = ['|','  ','|','  ','|','  ','|','  ','|','  ','|'];
const underLine = ['|____|','  ','|____|','  ','|____|'];

const superBowl = [tube1, tube2, tube3, tube4, tube5, underLine];


function twiceJoin(array) {
  let lines = []
  for (let index = 0; index < array.length; index++) {
    lines.push(array[index].join(' '));
  }
  return lines.join('\n');
}

console.log(twiceJoin(superBowl));
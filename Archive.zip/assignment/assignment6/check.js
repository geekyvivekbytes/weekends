function rowLength(value, range) {
  let reqOutput = value * 2 + 1;
  if (reqOutput > range) {
    reqOutput = range * 2 - reqOutput;
  }
  return reqOutput;
}

function padLength(length, line) {
  return ((length - line.length) / 2 + line.length);
}

function paddedString(diamondString, length) {
  return diamondString.padStart(padLength(length, diamondString));
}

function hollowDiamondRow(index, length) {
  const rowLen = rowLength(index, length);
  return makeARow(rowLen, "*", rowLen - 2);
}

function hollowDiamond(length) {
  const formedStructure = [];

  for (let index = 0; index < length; index++) {
    let line = hollowDiamondRow(index, length);
    line = paddedString(line, length);
    formedStructure.push(line);
  }
  return formedStructure;
}

function diamond(length) {
  const formedDiamond = [];

  for (let index = 0; index < length; index++) {
    let line = makeARow(rowLength(index, length));
    line = paddedString(line, length);
    formedDiamond.push(line);
  }

  return formedDiamond;
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTests() {
  test('first term', hollowDiamond(9), '*');
}
runAllTests();

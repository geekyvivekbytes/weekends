/*
  Implement the below function to convert a string from snake_case
  format into camelCase format.

  Example:
  toCamelCase("hello_wORLd_pro1gram")
    -> "helloWorldPro1gram"
*/
function startIndex(sentence) {
  for (let index = 0; index < sentence.length; index++) {
    let word = sentence[index];
    if (word !== '_') {
      return index;
    }
  }
}
function endIndex(sentence) {
  for (let index = sentence.length - 1; index >= 0; index--) {
    let word = sentence[index];
    if (word !== '_') {
      return index;
    }
  }
}

function toUpperCase(words) {
  const alphabates1 = 'abcdefghijklmnopqrstuvwxyz';
  const alphabates2 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let index = 0; index < alphabates1.length; index++) {
    if (alphabates1[index] === words) {
      return alphabates2[index];
    }
  }
}
function toLowerCase(words) {
  const alphabates2 = 'abcdefghijklmnopqrstuvwxyz';
  const alphabates1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let index = 0; index < alphabates1.length; index++) {
    if (alphabates1[index] === words) {
      return alphabates2[index];
    }
  }
}
function isUpper(words) {
  const alphabates1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let index = 0; index < alphabates1.length; index++) {
    if (alphabates1[index] === words) {
      return true;
    }
  }
  return false;
}
function toCamelCase(sentence) {
  // Implementation here.
  let camelCase = '';
  const startingIndex = startIndex(sentence);
  const endingIndex = endIndex(sentence);

  for (let index = startingIndex; index <= endingIndex; index++) {
    let word = sentence[index];
    if (!(word === '_')) {
      word = isUpper(word) ? toLowerCase(word) : word;
      camelCase = camelCase + word;
    }
    if (word === '_' && sentence[index + 1] !== '_') {
      word = sentence[index + 1];
      word = isUpper(word) ? word : toUpperCase(word);
      camelCase = camelCase + word;
      index++;
    }
  }
  return camelCase;
}
function messageComposer(string, expectedResult, camelCased) {
  const verifyString = expectedResult === camelCased;
  const emoji = verifyString ? '✅' : '❌';
  let message = emoji + '[' + string + ']';
  message += '|' + 'expected :' + expectedResult;
  message += '|' + 'actual :' + camelCased + '|';
  return message;
}
function checkToCamelCase(sentence, expectedResult) {
  const camelCased = toCamelCase(sentence);
  const message = messageComposer(sentence, expectedResult, camelCased);
  console.log(message);
}
function all() {
  checkToCamelCase('Rajesh_name', 'rajeshName');
  checkToCamelCase("mohit_name1", 'mohitName1');
  checkToCamelCase('notFound', 'notfound');
  checkToCamelCase('1_hello_World', '1HelloWorld');
  checkToCamelCase("____hello__wORLd_pro1gram", "helloWorldPro1gram");
  checkToCamelCase("_Hekko_", "hekko");
  checkToCamelCase("hello@w%_rld", "hello@w%Rld");
  checkToCamelCase("_hELlo_World", "helloWorld");
  checkToCamelCase("hello__world___Welcome_", "helloWorldWelcome");
  checkToCamelCase("_", "");
}
all();





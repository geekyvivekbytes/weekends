function decimalToBinary(a) {
  let givenNumber = a;
  let binaryDigits = 0;
  let power = 0;
  if (givenNumber === 0) {
    return a;
  }
  while (givenNumber > 0) {
    let binaryDigit = givenNumber % 2;
    givenNumber = (givenNumber - binaryDigit) / 2;
    binaryDigits = binaryDigits + (binaryDigit * (10 ** power));
    power++;
  }
  return binaryDigits;
}

function decimalToBinaryTest(a, b) {
  const binaryNO = decimalToBinary(a);
  const isBinaryNoEqual = binaryNO === b;
  const resultInImage = isBinaryNoEqual ? "✅" : "❌";
  console.log(
    resultInImage,
    "output result is",
    binaryNO,
    "and expected result was",
    b,
  );
}

decimalToBinaryTest(12, 1100);
decimalToBinaryTest(0, 0);
decimalToBinaryTest(1, 1);
decimalToBinaryTest(31, 11111);

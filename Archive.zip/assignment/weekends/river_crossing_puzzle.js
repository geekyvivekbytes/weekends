
function instruction() {
  console.log(`the goal is to move three doctor'👨‍⚕️' and three zombie'🧟‍♂️'
     across a river and only two people at a time,
     zombie should never outnumbering the doctor on either side,
     at least one person require to drive boat
     which is not impilimented yet, but go with process \n`);
}
const river = ['🛶', '🌊', '🌊', '🌊', '🌊', '🌊', '🌊'];

const zombie = ['🧟‍♂️', '🧟‍♂️', '🧟‍♂️'];
const doctor = ['👨‍⚕️', '👨‍⚕️', '👨‍⚕️']
const endSideDoctor = [];
const endSideZombie = [];
const display = [zombie, doctor, river, endSideDoctor, endSideZombie];


function delay() {
  for (let i = 0; i < 100890000; i++) {
  }
}
function arrivalOfBoat() {
  for (let index = river.length - 1; index >= 1; index--) {
    river[index - 1] = river[index];
    river[index] = '🌊';
    console.clear();
    console.log(river.join(''));
    delay();
  }
}

function departureOfBoat() {
  for (let index = 0; index < river.length - 1; index++) {
    river[index + 1] = river[index];
    river[index] = '🌊';
    console.clear();
    console.log(river.join(''));
    delay();
  }
}
function isHeWon() {
  if (zombie.length === 0 && doctor.length === 0) {
    return true;
  }
  return false;
}

function isHeLose() {
  const firstCondition = zombie.length > doctor.length && doctor.length > 0;
  const secondCondition = endSideDoctor.length < endSideZombie.length && endSideDoctor.length > 0;
  if (firstCondition || secondCondition) {
    return true;
  }
  return false;
}

function gameEnd() {
  return isHeLose() || isHeWon();
}

function twiceJoin(array) {
  let lines = [];
  for (let index = 0; index < array.length; index++) {
    lines.push(array[index].join(' '));
  }
  return lines.join(' ');
}

function update(index) {
  console.clear();
  if (index % 2 === 0) {
    departureOfBoat();
  }
  if (index % 2 === 1) {
    arrivalOfBoat();
  }
  console.log('\n', twiceJoin(display));
}
function side(index) {
  const sides = ['startSide', 'endSide'];
  return sides[index % 2];
}

function isZombie(firstletter) {
  return firstletter === 'z';
}

function updateEndSide(input) {

  for (let index = 0; index < input.length; index++) {
    if (isZombie(input[index]) && endSideZombie.length >= 1) {
      zombie.push(endSideZombie.pop());
    } else if (endSideDoctor.length >= 1) {
      doctor.push(endSideDoctor.pop());
    }
  }
}

function updateStartSide(input) {
  for (let index = 0; index < input.length; index++) {

    if (input[index] === 'z' && zombie.length >= 1) {
      endSideZombie.push(zombie.pop());
    } else if (doctor.length >= 1) {
      endSideDoctor.push(doctor.pop());
    }
  }
}

function isIncludes(input) {
  return 'dzz'.includes(input) || 'zdd'.includes(input);
}

function isInRange(input) {
  return (input.length) < 3;
}

isAvailable(input, index)

function isValidInput(input, index) {
  return !isInRange(input) || !isIncludes(input) || isAvailable(input, index);
}

function updateZD(index, input) {
  if (index % 2 === 1) {
    updateEndSide(input);
  } else {
    updateStartSide(input);
  }
}

function message(index) {
  if (index === 11 && !gameEnd()) {
    return 'you failed! maximumlimit reached.';
  }
  if (isHeWon()) {
    return `Congrats! you solve the puzzle💥💥💥`;
  }
  return `opps! you lose, doctors got killed`;
}

let index = 0;
function userInput() {
  while (!gameEnd() && index < 11) {
    console.log('No. of move left', 11 - index, ';');
    let input = prompt(`whom you want to cross from [${side(index)}] of river 'z' or 'd':`);
    input = input.toLowerCase();

    if (isValidInput(input, index)) {
      console.log('enter a valid input');
    } else {
      updateZD(index, input);
      update(index);
      index++;
    }
  }
  console.log(message(index));
}
function start() {
  update();
  instruction();
  userInput();
}
start();
// Do not rename a, use it as input for your program.
// While testing we will change their values.
// a will be always 1 or greater.
const a = 6;

// Print true(boolean) if a is prime otherwise print false(boolean). DO NOT print "true" or "false".
// Printing more than one output or printing anything other than prime or not prime might will be consider as error.
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
let isComposite = false;
for (let divisor = 2; divisor < a; divisor++) {
  let isdivisible = a % divisor === 0;
  isComposite = isComposite || isdivisible;
}
const isPrime = (a <= 1) ? isComposite : !isComposite;
console.log(isPrime);

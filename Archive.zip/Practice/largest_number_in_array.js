function maximumNumber(numbers) {
  if (numbers.length === 0) {
    return NaN;
  }
  let largeNumber = 0;
  for (let index = 0; index < numbers.length; index++) {
    largeNumber = Math.max(largeNumber, numbers[index]);
  }
  return largeNumber;
}

function test(description, actual, expected) {
  if (actual === expected) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

const number = [34, 34, 87, 98, 97];

function runAllTests() {
  test('checking function ', maximumNumber([34, 34, 87, 98, 97]), 98);
  test('checking with predefine array', maximumNumber(number), 98);
  test('array with string', maximumNumber([34, 42, 23, 'string']), NaN)
  test('empty array', maximumNumber([]), NaN);
  
}
runAllTests();
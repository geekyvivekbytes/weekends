const firstNumber = 12
const secondNumber = 16
const thirdNumber = 24
let hcf = 0
let lowestNumber = (firstNumber < secondNumber && firstNumber < thirdNumber) ? firstNumber : (secondNumber < firstNumber && secondNumber < thirdNumber) ? secondNumber : thirdNumber
for (let count = 1 ; count <= lowestNumber ; count = count + 1 ){
    if (firstNumber % count === 0 && secondNumber % count === 0 && thirdNumber % count === 0){
        hcf = count
    }

}

console.log('hcf of',firstNumber,',',secondNumber,',',thirdNumber , 'is',hcf);

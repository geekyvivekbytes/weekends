const givenNumber = 6;
let result = 1
for(let count = 1 ; count <= givenNumber ; count = count + 1){
    result = result * count
}
console.log('factorial of ', givenNumber ,'is' , result);
conditionDivision
|input|output||
|4|4|
|8|8|
|12| |
|16|16|
|20|20|
|24| |


|S.NO|INPUT|OUTPUT|
|1.|'L ZL Z'|0|
|2.|"ZL"|0|
|3.|"L     Z"|5|
|4.|'  L  L"|-1|
|5.|"ZZZ"|-1|
|6.|"L ZL Z"|0|
|7.|"Z LL Z"|2|
|8.|" L  ZL"|1|
|9.|"L  Z LL"|0|




|number|multiplication|       
|1     |5     |
|2     |10    |
|3     |15    |
|4     |20   |
|5     |25   |
|10    |50   |

|divisor|dividend|quotient|remainder|
|1|1|1|0|
|2|1|2|0|
|3|2|1|1|
|5|2|2|1|

2nd largest num
|num1|num2|num3|result|
|1|1|1|1|
|1|1|2|1|
|6|3|4|3|
|2|4|6|4|
|||||
|||||

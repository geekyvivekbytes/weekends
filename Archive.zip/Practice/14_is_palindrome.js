function isPalindrome(a) {
  let strNumber = "" + a;
  let palindrome = true;

  for (let index = 0; index < strNumber.length; index++) {
    const forwardDigit = strNumber[index];
    const reverseDigit = strNumber[strNumber.length - (1 + index)];
    const areDigitsEqual = forwardDigit === reverseDigit;
    palindrome = palindrome && areDigitsEqual;
  }
  return palindrome;
}

function checkPalindrome(a, b) {
  const palindrome = isPalindrome(a);
  const isTruePalindrome = palindrome === b;
  const resultInImage = isTruePalindrome ? "✅" : "❌";
  console.log(resultInImage, "output result is", palindrome, "and expected result was", b);
}

checkPalindrome(121, true);
checkPalindrome(12343212, false);
checkPalindrome(12378987321, true);

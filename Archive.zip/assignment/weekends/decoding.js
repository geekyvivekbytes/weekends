const START_OF_LIST = 'l';
const START_OF_INTEGER = 'i'
const END_OF_INTEGER = 'e';
const END_OF_LIST = 'e';
const COLON = ':';

function isArray(x) {
  return typeof x === 'object';
}

function areArraysEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (!areDeepEqual(array1[index], array2[index])) {
      return false;
    }
  }

  return true;
}

function areDeepEqual(array1, array2) {
  if (typeof array1 !== typeof array2) {
    return false;
  }

  if (isArray(array1) && isArray(array2)) {
    return areArraysEqual(array1, array2);
  }

  return array1 === array2;
}



function valueOf(target) {
  const targets = START_OF_INTEGER + START_OF_LIST + END_OF_LIST;
  const values = [1, 1, -1];
  if (targets.includes(target)) {
    return values[targets.indexOf(target)];
  }
  return 0;
}

function integerIndex(string, index) {
  for (let i = index; i > 0; i--) {
    if (!(parseInt(string[i]) <= 9)) {
      return i + 1;
    }
  }
  return 1;
}

function endIndexForList(encodedMessage, index = 0, count = 0) {
  while (index < encodedMessage.length && encodedMessage[index] !== COLON) {
    count += valueOf(encodedMessage[index]);

    if (count === 0 && encodedMessage[index] === END_OF_LIST) {
      return index + 1;
    }

    index++;
  }

  const firstIntegerIndex = integerIndex(encodedMessage, index - 1);
  const lengthOfString = parseInt(encodedMessage.slice(firstIntegerIndex, index)) + 1;
  return endIndexForList(encodedMessage, index + lengthOfString, count)
}
function trimEncodedString(encodedMessage, index) {
  const indexOfColon = encodedMessage.indexOf(COLON) + 1;
  const lengthOfString = parseInt(encodedMessage.slice(0, indexOfColon - 1));
  const lengthOfEncodedString = indexOfColon + lengthOfString;
  return [encodedMessage.slice(0, lengthOfEncodedString), lengthOfEncodedString + index];
}

function seperateElement(encodedMessage, index) {

  const newMessage = encodedMessage.slice(index)
  const firstLetter = newMessage[0];
  if (firstLetter === START_OF_INTEGER || firstLetter === START_OF_LIST) {
    const endIndex = endIndexForList(newMessage);
    return [newMessage.slice(0, endIndex), endIndex + index];
  }
  return trimEncodedString(newMessage, index);
}

function formArray(encodedMessage) {
  const encodedArray = [];
  let index = 1;

  while (index < encodedMessage.length - 1) {
    const array = seperateElement(encodedMessage, index);

    encodedArray.push(array[0]);
    index = array[1];
  }
  return encodedArray;
}


function decodeArray(encodedMessage) {
  const encodedArray = formArray(encodedMessage);
  const decodedArray = [];

  for (let index = 0; index < encodedArray.length; index++) {
    decodedArray.push(decoder(encodedArray[index]));
  }
  return decodedArray;
}

function decodeString(encodedMessage) {
  const indexOfColon = encodedMessage.indexOf(COLON) + 1;
  const lengthOfString = parseInt(encodedMessage.slice(0, indexOfColon - 1));
  return encodedMessage.slice(indexOfColon, indexOfColon + lengthOfString);
}

function decodeNumbers(encodedNumber) {
  return parseInt(encodedNumber.slice(1, encodedNumber.indexOf(END_OF_INTEGER)));
}

function decoder(encodedMessage) {
  const firstLetter = encodedMessage[0];
  switch (firstLetter) {
    case START_OF_INTEGER:
      return decodeNumbers(encodedMessage);
    case START_OF_LIST:
      return decodeArray(encodedMessage);
  }
  return decodeString(encodedMessage);
}

function test(description, actual, expected) {
  if (areDeepEqual(actual, expected)) {
    console.log(`✅ ${description}`);
    return;
  }
  console.log(`❌ ${description}`);
  console.log(`     Expected: <${expected}>, Actual: <${actual}>`);
}

function runAllTest() {
  test('only integer', decoder('i234e'), 234);
  test('negative integer', decoder("i-42e"), -42);
  test('string', decoder('5:hello'), 'hello');
  test('empty string', decoder('0:'), '');
  test('empty integer', decoder('i0e'), 0);
  test('nested array', decoder("lle5:applei123el6:bananai-5eee"), [[], "apple", 123, ["banana", -5]]);
  test('array with empty string and array as well as zero', decoder("l0:i0elee"), ["", 0, []]);

}

runAllTest()


